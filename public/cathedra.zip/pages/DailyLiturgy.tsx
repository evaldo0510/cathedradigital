
import React, { useState, useEffect, useContext, useCallback } from 'react';
import { Icons } from '../constants';
import { getNativeLiturgy } from '../services/nativeData';
import { LangContext } from '../App';
import ActionButtons from '../components/ActionButtons';
import { DailyLiturgyContent } from '../types';

const DailyLiturgy: React.FC = () => {
  const { lang } = useContext(LangContext);
  const urlParams = new URLSearchParams(window.location.search);
  const initialDate = urlParams.get('date') || new Date().toISOString().split('T')[0];
  
  const [date, setDate] = useState(initialDate);
  const [data, setData] = useState<DailyLiturgyContent | null>(null);
  const [fontSize, setFontSize] = useState(1.25);
  const [loading, setLoading] = useState(true);
  const [immersive, setImmersive] = useState(false);

  const loadContent = useCallback(async (targetDate: string) => {
    setLoading(true);
    // Simulação de carregamento para efeito visual premium
    await new Promise(resolve => setTimeout(resolve, 400));
    try {
      const localData = getNativeLiturgy(targetDate);
      setData(localData);
    } catch (e) {
      console.error("Liturgy Load Error:", e);
    } finally {
      setLoading(false);
      window.scrollTo({ top: 0, behavior: 'smooth' });
    }
  }, []);

  useEffect(() => {
    loadContent(date);
  }, [date, loadContent]);

  const changeDate = (offset: number) => {
    const d = new Date(date + 'T12:00:00');
    d.setDate(d.getDate() + offset);
    const newDate = d.toISOString().split('T')[0];
    setDate(newDate);
    
    const newUrl = new URL(window.location.href);
    newUrl.searchParams.set('date', newDate);
    window.history.replaceState({}, '', newUrl);
  };

  const getDateLabel = (offset: number) => {
    const d = new Date(date + 'T12:00:00');
    d.setDate(d.getDate() + offset);
    return d.toLocaleDateString(lang, { day: 'numeric', month: 'short' });
  };

  return (
    <div className={`transition-all duration-1000 min-h-screen ${immersive ? 'bg-[#fdfcf8] text-[#3e3a32]' : 'bg-transparent'} pb-60`}>
      
      {/* CONTROLES DE LEITURA (ESTILO SCRIPTORIUM) */}
      <div className="sticky top-24 z-[140] flex justify-center mb-16 pointer-events-none px-4">
        <div className="pointer-events-auto bg-white/95 dark:bg-stone-900/95 backdrop-blur-2xl border border-stone-200 dark:border-stone-800 px-6 md:px-8 py-3 rounded-[2.5rem] shadow-premium flex items-center gap-6 md:gap-8">
          <div className="flex items-center gap-4 md:gap-5 border-r border-stone-200 dark:border-stone-800 pr-6 md:pr-8 text-stone-900 dark:text-white">
            <button onClick={() => setFontSize(f => Math.max(1, f - 0.1))} className="hover:text-gold transition-colors font-bold text-base md:text-lg">A-</button>
            <div className="w-px h-4 bg-stone-200 dark:bg-stone-800" />
            <button onClick={() => setFontSize(f => Math.min(2.5, f + 0.1))} className="hover:text-gold transition-colors font-bold text-xl md:text-2xl">A+</button>
          </div>
          
          <div className="flex items-center gap-3">
             <button 
              onClick={() => setImmersive(!immersive)}
              className={`flex items-center gap-2 px-4 py-2 rounded-xl text-[9px] md:text-[10px] font-black uppercase tracking-widest transition-all ${immersive ? 'bg-stone-950 text-white shadow-md' : 'text-stone-400 hover:bg-stone-50 dark:hover:bg-stone-800'}`}
             >
               <Icons.Star className="w-3 h-3" />
               <span>{immersive ? 'Modo Oração' : 'Modo Estudo'}</span>
             </button>
          </div>
        </div>
      </div>

      <div className="max-w-4xl mx-auto px-6">
        {/* HEADER MONUMENTAL */}
        <header className="text-center mb-24 space-y-6">
          <div className="flex items-center justify-center gap-6 mb-4">
             <div className="h-px w-16 bg-gold/30" />
             <span className="text-[10px] font-black uppercase tracking-[0.6em] text-gold">Lumen Diei</span>
             <div className="h-px w-16 bg-gold/30" />
          </div>
          <h1 className="text-4xl md:text-7xl font-serif font-bold text-stone-900 dark:text-stone-100 tracking-tighter leading-none">
            {new Date(date + 'T12:00:00').toLocaleDateString(lang, { day: 'numeric', month: 'long', year: 'numeric' })}
          </h1>
          <p className="text-xl md:text-3xl text-stone-400 font-serif italic capitalize">
            {new Date(date + 'T12:00:00').toLocaleDateString(lang, { weekday: 'long' })}
          </p>
          
          {/* NAVEGAÇÃO DE TOPO */}
          <div className="flex justify-center items-center gap-6 pt-6">
            <button onClick={() => changeDate(-1)} className="p-4 bg-white dark:bg-stone-900 rounded-2xl shadow-sm border border-stone-100 dark:border-stone-800 hover:border-gold transition-all">
              <Icons.ArrowDown className="w-5 h-5 rotate-90 text-stone-400 hover:text-gold" />
            </button>
            <div className="h-px w-12 bg-stone-100 dark:bg-stone-800" />
            <button onClick={() => changeDate(1)} className="p-4 bg-white dark:bg-stone-900 rounded-2xl shadow-sm border border-stone-100 dark:border-stone-800 hover:border-gold transition-all">
              <Icons.ArrowDown className="w-5 h-5 -rotate-90 text-stone-400 hover:text-gold" />
            </button>
          </div>
        </header>

        {loading ? (
          <div className="py-40 text-center space-y-6">
             <div className="w-12 h-12 border-4 border-gold border-t-transparent rounded-full animate-spin mx-auto" />
             <p className="text-xl font-serif italic text-stone-400">Preparando a Mesa da Palavra...</p>
          </div>
        ) : data && (
          <div className="space-y-32" style={{ fontSize: `${fontSize}rem` }}>
            
            {/* COLETA */}
            <section className="text-center italic space-y-8 animate-in fade-in duration-700">
               <span className="text-[10px] font-black uppercase tracking-[0.4em] text-sacred">Oratio Collecta</span>
               <p className="font-serif text-3xl md:text-5xl leading-[1.3] text-stone-800 dark:text-stone-200 max-w-2xl mx-auto selection:bg-gold/30">
                 "{data.collect}"
               </p>
            </section>

            {/* I LEITURA */}
            <article className="space-y-10 animate-in slide-in-from-bottom-6 duration-700">
               <header className="flex justify-between items-end border-b border-stone-100 dark:border-stone-800 pb-4">
                  <div className="space-y-1">
                    <span className="text-[10px] font-black uppercase text-gold tracking-widest">Lectio Prima</span>
                    <h3 className="text-3xl font-serif font-bold text-stone-900 dark:text-stone-100">{data.firstReading.reference}</h3>
                  </div>
                  <ActionButtons itemId={`lit_l1_${date}`} type="liturgy" title={`Leitura - ${date}`} content={data.firstReading.text} />
               </header>
               <div className="font-serif text-stone-800 dark:text-stone-300 leading-[1.8] text-justify indent-12 selection:bg-gold/30">
                 {data.firstReading.text}
               </div>
            </article>

            {/* SALMO */}
            <section className="bg-stone-900 dark:bg-stone-950 p-12 md:p-20 rounded-[4rem] text-center space-y-8 shadow-sacred relative overflow-hidden group">
               <div className="absolute inset-0 opacity-10 bg-[url('https://www.transparenttextures.com/patterns/natural-paper.png')] pointer-events-none" />
               <span className="text-[11px] font-black uppercase text-gold/50 tracking-[0.8em]">Psalmus</span>
               <p className="text-xs md:text-sm font-bold text-sacred uppercase tracking-[0.3em]">{data.psalm.title}</p>
               <h4 className="font-serif font-bold text-3xl md:text-6xl text-white italic leading-tight group-hover:scale-105 transition-transform duration-700">
                 "{data.psalm.text}"
               </h4>
            </section>

            {/* EVANGELHO */}
            <article className="space-y-12 animate-in slide-in-from-bottom-8 duration-700">
               <header className="flex justify-between items-end border-b border-stone-100 dark:border-stone-800 pb-4">
                  <div className="space-y-1">
                    <span className="text-[11px] font-black uppercase text-sacred tracking-[0.5em]">Sanctum Evangelium</span>
                    <h3 className="text-4xl md:text-5xl font-serif font-bold text-stone-900 dark:text-stone-100">{data.gospel.reference}</h3>
                  </div>
                  <ActionButtons itemId={`lit_gospel_${date}`} type="liturgy" title={`Evangelho - ${date}`} content={data.gospel.text} />
               </header>
               <div className="font-serif text-stone-900 dark:text-white font-bold text-3xl md:text-4xl leading-[1.7] text-justify italic indent-12 selection:bg-sacred/20 drop-shadow-sm">
                 {data.gospel.text}
               </div>

               {data.gospel.reflection && (
                  <div className="mt-16 p-10 bg-stone-50 dark:bg-stone-900/40 rounded-[3rem] border-l-[12px] border-gold shadow-inner group">
                    <Icons.Feather className="w-8 h-8 text-gold/20 mb-6 group-hover:rotate-12 transition-transform" />
                    <p className="font-serif italic text-xl md:text-2xl text-stone-600 dark:text-stone-400 leading-relaxed text-justify">
                      {data.gospel.reflection}
                    </p>
                  </div>
               )}
            </article>

            {/* NAVEGAÇÃO DE RODAPÉ (DINÂMICA) */}
            <nav className="grid grid-cols-2 gap-6 md:gap-12 pt-16 border-t border-stone-100 dark:border-stone-800">
              <button 
                onClick={() => changeDate(-1)}
                className="group flex items-center gap-4 text-left transition-all active:scale-95"
              >
                <div className="p-4 rounded-2xl bg-stone-50 dark:bg-stone-900 border border-stone-100 dark:border-stone-800 group-hover:border-gold transition-colors shadow-sm">
                  <Icons.ArrowDown className="w-5 h-5 rotate-90 text-stone-400 group-hover:text-gold transition-transform group-hover:-translate-x-1" />
                </div>
                <div>
                  <span className="block text-[10px] font-black uppercase tracking-[0.2em] text-stone-400 mb-1">Anterior</span>
                  <span className="block text-xl md:text-2xl font-serif font-bold text-stone-900 dark:text-stone-100 leading-none">
                    {getDateLabel(-1)}
                  </span>
                </div>
              </button>

              <button 
                onClick={() => changeDate(1)}
                className="group flex items-center justify-end gap-4 text-right transition-all active:scale-95"
              >
                <div>
                  <span className="block text-[10px] font-black uppercase tracking-[0.2em] text-stone-400 mb-1">Seguinte</span>
                  <span className="block text-xl md:text-2xl font-serif font-bold text-gold leading-none">
                    {getDateLabel(1)}
                  </span>
                </div>
                <div className="p-4 rounded-2xl bg-stone-900 text-gold border border-stone-800 group-hover:bg-sacred group-hover:text-white transition-all shadow-xl">
                  <Icons.ArrowDown className="w-5 h-5 -rotate-90 transition-transform group-hover:translate-x-1" />
                </div>
              </button>
            </nav>
          </div>
        )}
      </div>

      <footer className="mt-40 pt-20 border-t border-stone-100 dark:border-stone-800 text-center opacity-20">
        <Icons.Cross className="w-12 h-12 mx-auto mb-6 text-stone-400" />
        <p className="text-[12px] font-black uppercase tracking-[1em]">Lex Orandi • Lex Credendi</p>
      </footer>
    </div>
  );
};

export default DailyLiturgy;
