
import React, { useState, useEffect } from 'react';
import { Icons } from '../constants';
import { LearningTrack, TrackStep } from '../types';
import { tracksService } from '../services/tracksService';
import SacredImage from '../components/SacredImage';
import Progress from '../components/Progress';
import TrailCard from '../components/TrailCard';

interface TracksProps {
  onNavigateBible: (book: string, chapter: number) => void;
  onNavigateCIC: (para: number) => void;
  userId?: string;
}

const Tracks: React.FC<TracksProps> = ({ onNavigateBible, onNavigateCIC, userId }) => {
  const [tracks, setTracks] = useState<LearningTrack[]>([]);
  const [selectedTrack, setSelectedTrack] = useState<LearningTrack | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const loadData = async () => {
      setLoading(true);
      const data = await tracksService.getAllTracks();
      // Garantir a ordem estratégica das 5 trilhas
      setTracks(data);
      setLoading(false);
    };
    loadData();
  }, []);

  const handleStepAction = (step: TrackStep) => {
    if (step.type === 'biblia') {
       const parts = step.ref.split(' ');
       const book = parts.slice(0, -1).join(' ');
       const chapterStr = parts[parts.length - 1]?.split(':')[0];
       const chapter = parseInt(chapterStr);
       if (book && !isNaN(chapter)) onNavigateBible(book, chapter);
    } else if (step.type === 'cic') {
       const para = parseInt(step.ref);
       if (!isNaN(para)) onNavigateCIC(para);
    }
  };

  if (selectedTrack) {
    return (
      <div className="max-w-5xl mx-auto space-y-12 pb-48 animate-in fade-in duration-500">
        <button 
          onClick={() => setSelectedTrack(null)}
          className="flex items-center gap-3 text-[10px] font-black uppercase tracking-widest text-stone-400 hover:text-gold transition-colors"
        >
          <Icons.ArrowDown className="w-4 h-4 rotate-90" /> Voltar à Formação
        </button>

        <header className="relative h-[30vh] md:h-[40vh] rounded-[3rem] md:rounded-[4rem] overflow-hidden shadow-4xl group">
           <SacredImage src={selectedTrack.image || ""} alt={selectedTrack.title} className="w-full h-full" priority={true} />
           <div className="absolute inset-0 bg-gradient-to-t from-stone-950 via-stone-900/40 to-transparent" />
           <div className="absolute bottom-10 left-10 right-10">
              <div className="space-y-4">
                 <div className="flex flex-wrap gap-2">
                    <span className="px-4 py-1.5 bg-gold text-stone-900 rounded-full text-[9px] font-black uppercase tracking-widest">{selectedTrack.level}</span>
                    <span className="px-4 py-1.5 bg-white/20 backdrop-blur-md text-white rounded-full text-[9px] font-black uppercase tracking-widest">
                       {selectedTrack.id === 'maturidade-crista' ? 'Aprofundamento' : 'Acesso Gratuito'}
                    </span>
                 </div>
                 <h2 className="text-4xl md:text-7xl font-serif font-bold text-white tracking-tighter leading-none">{selectedTrack.title}</h2>
              </div>
           </div>
        </header>

        <div className="grid lg:grid-cols-12 gap-12">
           <div className="lg:col-span-8 space-y-10">
              {selectedTrack.modules.map((module, mIdx) => (
                <section key={module.id} className="space-y-8 animate-in slide-in-from-bottom-4" style={{ animationDelay: `${mIdx * 100}ms` }}>
                  <div className="flex items-center gap-6">
                    <div className="w-14 h-14 rounded-3xl bg-stone-900 text-gold flex items-center justify-center font-serif text-3xl font-bold shadow-xl border border-white/5">
                      {mIdx + 1}
                    </div>
                    <h3 className="text-3xl font-serif font-bold text-stone-900 dark:text-stone-100">{module.title}</h3>
                  </div>

                  <div className="grid gap-4 ml-6 md:ml-20">
                      {module.content.map((step, sIdx) => (
                        <button 
                          key={sIdx}
                          onClick={() => handleStepAction(step)}
                          className="w-full text-left p-8 bg-white dark:bg-stone-900 border border-stone-100 dark:border-stone-800 rounded-[2.5rem] hover:border-gold hover:shadow-2xl transition-all group flex items-center justify-between"
                        >
                          <div className="flex items-center gap-6">
                              <div className="p-4 bg-stone-50 dark:bg-stone-800 rounded-2xl text-sacred group-hover:text-gold transition-colors">
                                {step.type === 'biblia' ? <Icons.Book className="w-6 h-6" /> : step.type === 'cic' ? <Icons.Cross className="w-6 h-6" /> : <Icons.Feather className="w-6 h-6" />}
                              </div>
                              <div className="space-y-1">
                                <p className="text-[10px] font-black uppercase text-stone-400 tracking-widest">{step.type} • {step.ref}</p>
                                <h4 className="text-2xl font-serif font-bold dark:text-stone-200">{step.label || 'Ver conteúdo'}</h4>
                              </div>
                          </div>
                          <Icons.ArrowDown className="w-6 h-6 -rotate-90 text-stone-200 group-hover:text-gold transition-transform group-hover:translate-x-2" />
                        </button>
                      ))}
                  </div>
                </section>
              ))}
           </div>

           <aside className="lg:col-span-4 space-y-8">
              <div className="p-10 bg-[#fcf8e8] dark:bg-stone-900 rounded-[3rem] border border-gold/20 shadow-xl space-y-6">
                 <div className="flex items-center gap-4 text-gold">
                    <Icons.History className="w-6 h-6" />
                    <h4 className="text-sm font-serif font-bold">Objetivo da Trilha</h4>
                 </div>
                 <p className="text-stone-600 dark:text-stone-400 font-serif italic leading-relaxed text-xl">
                   {selectedTrack.description}
                 </p>
              </div>
              <div className="p-10 bg-stone-900 text-white rounded-[3.5rem] shadow-3xl relative overflow-hidden group">
                 <Icons.Cross className="absolute -bottom-10 -right-10 w-48 h-48 opacity-[0.03] group-hover:scale-110 transition-transform duration-1000" />
                 <h4 className="text-[11px] font-black uppercase tracking-[0.5em] text-gold mb-6">Escola da Fé</h4>
                 <p className="font-serif italic text-lg text-white/80 leading-relaxed">"A Igreja ensina por ordem, não por acaso. Este currículo organiza a sabedoria milenar para sua formação contínua."</p>
              </div>
           </aside>
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-6xl mx-auto space-y-16 animate-in fade-in duration-700 pb-48 pt-10">
      <header className="text-center space-y-6 max-w-4xl mx-auto">
        <div className="flex justify-center mb-4">
           <div className="p-6 bg-white dark:bg-stone-900 rounded-[2.5rem] shadow-sacred border border-gold/20 rotate-3 transition-transform hover:rotate-0">
              <Icons.Feather className="w-12 h-12 text-sacred" />
           </div>
        </div>
        <h2 className="text-5xl md:text-[8rem] font-serif font-bold text-stone-900 dark:text-gold tracking-tighter leading-none">Formação</h2>
        <p className="text-stone-400 italic text-2xl md:text-3xl font-serif leading-relaxed">
          "Início gratuito com aprofundamentos organizados por trilhas pedagógicas, do simples ao profundo."
        </p>
      </header>

      {loading ? (
        <div className="py-24 text-center">
           <div className="w-16 h-16 border-4 border-gold border-t-transparent rounded-full animate-spin mx-auto mb-8 shadow-sacred" />
           <p className="text-2xl font-serif italic text-stone-400">Organizando o currículo da tradição...</p>
        </div>
      ) : (
        <div className="grid md:grid-cols-2 gap-10">
          {tracks.map((track, i) => (
            <TrailCard 
              key={track.id} 
              track={track} 
              onClick={setSelectedTrack} 
            />
          ))}
        </div>
      )}
      
      <div className="bg-stone-950 p-12 md:p-24 rounded-[4rem] md:rounded-[6rem] border border-stone-800 text-center space-y-8 relative overflow-hidden group">
          <div className="absolute inset-0 bg-gradient-to-br from-sacred/10 via-transparent to-sacred/10" />
          <Icons.Star className="w-16 h-16 text-gold mx-auto mb-4 relative z-10 animate-pulse" />
          <h3 className="text-4xl md:text-6xl font-serif font-bold text-white relative z-10">Mediação Formativa</h3>
          <p className="text-stone-400 font-serif italic text-xl md:text-2xl max-w-3xl mx-auto relative z-10 leading-relaxed">
             As fontes (Bíblia, CIC, Docs) são sempre gratuitas. O aprofundamento futuro oferecerá guias, comentários pedagógicos e sínteses para sua plena maturidade cristã.
          </p>
      </div>

      <footer className="text-center opacity-30 pt-20">
        <Icons.Cross className="w-12 h-12 mx-auto" />
      </footer>
    </div>
  );
};

export default Tracks;
