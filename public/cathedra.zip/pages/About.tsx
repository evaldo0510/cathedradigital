
import React from 'react';
import { Icons, Logo } from '../constants';

const About: React.FC = () => {
  return (
    <div className="max-w-6xl mx-auto space-y-32 animate-in fade-in slide-in-from-bottom-10 duration-1000 pb-48 pt-10 px-4">
      
      {/* Header Sacro */}
      <header className="text-center space-y-12">
        <div className="flex justify-center">
          <div className="p-8 bg-stone-950 rounded-[3rem] shadow-4xl border border-gold/30 rotate-3 hover:rotate-0 transition-transform duration-700 group">
            <Logo className="w-24 h-24 group-hover:scale-110 transition-transform" />
          </div>
        </div>
        <div className="space-y-6">
          <span className="text-[12px] font-black uppercase tracking-[0.8em] text-gold block">Identidade & Propósito</span>
          <h1 className="text-5xl md:text-9xl font-serif font-bold text-stone-900 dark:text-stone-100 tracking-tighter leading-none">
            SOBRE O CATHEDRA
          </h1>
          <div className="h-px w-24 bg-sacred/40 mx-auto" />
        </div>
      </header>

      {/* Quem Somos */}
      <section className="grid lg:grid-cols-2 gap-16 items-start">
         <div className="space-y-10">
            <h2 className="text-4xl md:text-6xl font-serif font-bold text-stone-900 dark:text-stone-100 leading-tight tracking-tight">O que é este <br /><span className="text-gold italic">Santuário Digital.</span></h2>
            <p className="text-xl md:text-2xl text-stone-600 dark:text-stone-400 font-serif leading-relaxed italic">
              Cathedra é uma plataforma de formação católica dedicada ao estudo fiel da fé, em plena comunhão com o Magistério da Igreja. 
              Organizamos, facilitamos e conduzimos o estudo das fontes oficiais através da inteligência teológica.
            </p>
         </div>
         <div className="grid gap-6">
            <div className="bg-white dark:bg-stone-900 p-10 rounded-[3rem] shadow-xl border border-stone-100 dark:border-stone-800 space-y-4">
               <h4 className="text-[10px] font-black uppercase tracking-widest text-sacred">O que NÃO somos</h4>
               <p className="text-lg font-serif italic text-stone-500">
                  "Não substituímos a Igreja, nem interpretamos fora dela. Não somos um substituto para a vida paroquial ou sacramental."
               </p>
            </div>
            <div className="bg-stone-900 p-10 rounded-[3rem] shadow-2xl text-white space-y-4 relative overflow-hidden">
               <Icons.Cross className="absolute -bottom-6 -right-6 w-32 h-32 opacity-5" />
               <h4 className="text-[10px] font-black uppercase tracking-widest text-gold">Nosso Compromisso</h4>
               <p className="text-lg font-serif italic text-white/80">
                  "Oferecer o depósito da fé com rigor escolástico, clareza pedagógica e reverência litúrgica."
               </p>
            </div>
         </div>
      </section>

      {/* Corpo do Manifesto */}
      <section className="bg-white dark:bg-stone-900 p-12 md:p-32 rounded-[4rem] shadow-4xl border border-stone-100 dark:border-stone-800 relative overflow-hidden">
        <div className="absolute top-0 right-0 p-12 opacity-[0.02] pointer-events-none">
           <Icons.Cross className="w-[40rem] h-[40rem] text-gold" />
        </div>
        
        <article className="max-w-3xl mx-auto space-y-16 relative z-10 text-center md:text-left">
          <div className="space-y-8">
            <p className="text-3xl md:text-5xl font-serif font-bold text-stone-800 dark:text-stone-200 leading-none tracking-tighter">
              O M A N I F E S T O
            </p>
            <p className="text-2xl md:text-4xl font-serif text-stone-800 dark:text-stone-200 leading-snug">
              Cathedra nasce do desejo de formar <span className="text-sacred font-bold italic">consciências</span>, não opiniões.
            </p>
            <p className="text-xl md:text-2xl text-stone-500 italic font-serif leading-relaxed">
              Acreditamos que a fé católica não precisa ser simplificada — precisa ser bem conduzida por quem conhece o caminho.
            </p>
          </div>

          <div className="grid md:grid-cols-2 gap-12 border-y border-stone-100 dark:border-stone-800 py-16">
            <div className="space-y-4">
              <h4 className="text-[10px] font-black uppercase tracking-[0.4em] text-gold">A Escuta</h4>
              <p className="text-lg font-serif italic text-stone-600 dark:text-stone-400 leading-relaxed">
                Aqui, a Palavra é estudada com reverência. O Catecismo é lido com profundidade. Os Documentos da Igreja são acessados em sua fonte, sem atalhos ideológicos.
              </p>
            </div>
            <div className="space-y-4">
              <h4 className="text-[10px] font-black uppercase tracking-[0.4em] text-sacred">A Meta</h4>
              <ul className="space-y-3 text-xl font-serif font-bold text-stone-900 dark:text-stone-100">
                <li>• Compreender o que crê</li>
                <li>• Amar aquilo que estuda</li>
                <li>• Viver aquilo que aprende</li>
              </ul>
            </div>
          </div>

          <div className="space-y-12">
            <div className="bg-[#fcf8e8] dark:bg-stone-800/50 p-12 rounded-[3.5rem] text-center space-y-6 border border-gold/10 shadow-inner">
              <p className="text-2xl md:text-3xl font-serif italic text-stone-900 dark:text-stone-100 leading-relaxed">
                "Formação não é acúmulo de informação. É transformação silenciosa da mente e do coração pela Verdade."
              </p>
            </div>

            <p className="text-xl font-serif text-stone-600 dark:text-stone-400 leading-relaxed text-center italic">
              Cathedra é lugar de estudo, de silêncio e de fidelidade apostólica.
            </p>
          </div>

          <div className="flex flex-col md:flex-row justify-center items-center gap-12 pt-10">
            <div className="text-center group">
               <div className="w-16 h-16 bg-stone-50 dark:bg-stone-800 rounded-2xl flex items-center justify-center mx-auto mb-4 group-hover:bg-gold transition-all shadow-sm">
                  <Icons.Book className="w-6 h-6 text-stone-400 group-hover:text-stone-900" />
               </div>
               <span className="text-[10px] font-black uppercase tracking-widest text-stone-400">Escritura</span>
            </div>
            <div className="h-px w-16 bg-stone-200 hidden md:block" />
            <div className="text-center group">
               <div className="w-16 h-16 bg-stone-50 dark:bg-stone-800 rounded-2xl flex items-center justify-center mx-auto mb-4 group-hover:bg-sacred transition-all shadow-sm">
                  <Icons.Cross className="w-6 h-6 text-stone-400 group-hover:text-white" />
               </div>
               <span className="text-[10px] font-black uppercase tracking-widest text-stone-400">Tradição</span>
            </div>
            <div className="h-px w-16 bg-stone-200 hidden md:block" />
            <div className="text-center group">
               <div className="w-16 h-16 bg-stone-50 dark:bg-stone-800 rounded-2xl flex items-center justify-center mx-auto mb-4 group-hover:bg-stone-900 transition-all shadow-sm">
                  <Icons.Globe className="w-6 h-6 text-stone-400 group-hover:text-gold" />
               </div>
               <span className="text-[10px] font-black uppercase tracking-widest text-stone-400">Magistério</span>
            </div>
          </div>
        </article>
      </section>

      {/* Footer do Manifesto */}
      <footer className="text-center pt-20 space-y-8">
        <Logo className="w-20 h-20 mx-auto opacity-10" />
        <p className="text-[12px] font-black uppercase tracking-[1em] text-stone-300 dark:text-stone-800">Tudo em um só caminho.</p>
      </footer>
    </div>
  );
};

export default About;
