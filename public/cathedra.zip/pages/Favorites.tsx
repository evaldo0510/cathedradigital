
import React, { useState, useEffect } from 'react';
import { Trash2, Heart, Star, BookOpen, Scroll } from 'lucide-react';
import { SavedItem } from '../types';

const Favorites: React.FC = () => {
  const [notes, setNotes] = useState<SavedItem[]>(() => 
    JSON.parse(localStorage.getItem('cathedra_saved_items') || '[]')
  );
  const [inputText, setInputText] = useState('');

  useEffect(() => {
    localStorage.setItem('cathedra_saved_items', JSON.stringify(notes));
    window.dispatchEvent(new CustomEvent('cathedra-saved-updated'));
  }, [notes]);

  const addManualNote = () => {
    if (!inputText.trim()) return;
    const newItem: SavedItem = {
      id: Date.now().toString(),
      type: 'study',
      title: "Reflexão Pessoal",
      content: inputText.trim(),
      timestamp: new Date().toISOString(),
      metadata: { isManual: true }
    };
    setNotes([newItem, ...notes]);
    setInputText('');
  };

  const removeItem = (id: string) => {
    setNotes(notes.filter(n => n.id !== id));
  };

  return (
    <div className="max-w-4xl mx-auto py-10 md:py-20 animate-fade-in">
      <header className="mb-16 text-center md:text-left">
        <h1 className="text-5xl md:text-7xl font-serif font-bold text-slate-900 mb-4 tracking-tighter">Memória do Espírito</h1>
        <p className="text-slate-500 text-lg md:text-xl font-medium">Guarde as suas reflexões teológicas e orações numa linha do tempo sagrada.</p>
      </header>

      <div className="bg-white p-6 md:p-10 rounded-[3rem] border border-slate-100 shadow-sm mb-12">
         <textarea 
          value={inputText}
          onChange={e => setInputText(e.target.value)}
          placeholder="O que o Verbo lhe diz hoje?" 
          className="w-full h-48 p-4 md:p-8 bg-slate-50 rounded-3xl border-none outline-none font-serif italic text-2xl resize-none mb-6 placeholder:text-slate-200" 
         />
         <button 
          onClick={addManualNote}
          className="w-full md:w-auto px-12 py-5 bg-blue-800 text-white rounded-2xl font-black text-xs uppercase tracking-widest shadow-xl hover:bg-blue-900 transition-all active:scale-95"
         >
          Guardar Reflexão
         </button>
      </div>

      <div className="space-y-6">
        {notes.length > 0 ? (
          notes.map(n => (
            <div key={n.id} className="p-8 bg-white border border-slate-50 rounded-[2.5rem] shadow-sm hover:shadow-md transition-all group relative overflow-hidden">
               <div className="flex justify-between items-start mb-4">
                  <div className="flex gap-2">
                    <span className="px-3 py-1 bg-blue-50 text-blue-700 text-[9px] font-black uppercase rounded-full flex items-center gap-1.5">
                       {n.type === 'verse' ? <BookOpen size={10} /> : n.type === 'catechism' ? <Scroll size={10} /> : <Heart size={10} />}
                       {n.title}
                    </span>
                    <span className="text-[9px] text-slate-300 font-bold uppercase py-1">{new Date(n.timestamp).toLocaleDateString()}</span>
                  </div>
                  <button 
                    onClick={() => removeItem(n.id)} 
                    className="opacity-0 group-hover:opacity-100 text-red-300 hover:text-red-500 transition-all"
                  >
                    <Trash2 size={18}/>
                  </button>
               </div>
               <p className="font-serif italic text-lg md:text-2xl text-slate-700 leading-relaxed">"{n.content}"</p>
            </div>
          ))
        ) : (
          <div className="py-20 text-center opacity-20 grayscale">
             <Star size={64} className="mx-auto mb-6" />
             <p className="text-2xl font-serif italic">Nenhum tesouro guardado em sua memória ainda.</p>
          </div>
        )}
      </div>
    </div>
  );
};

export default Favorites;
