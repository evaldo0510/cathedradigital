
import React, { useState, useCallback, useMemo, useRef, useEffect } from 'react';
import { Icons } from '../constants';
import { CATHOLIC_BIBLE_BOOKS, Book } from '../services/bibleLocal';
import { bibleService } from '../services/bibleService';
import { Verse, UniversalSearchResult } from '../types';
import BibleReader from '../components/BibleReader';
import ChapterNavigation from '../components/ChapterNavigation';

interface BibleProps {
  initialBook?: string;
  initialChapter?: number;
  onBibleJump: (book: string, chapter: number, verse: number) => void;
  onCatechismJump: (para: number) => void;
}

const Bible: React.FC<BibleProps> = ({ initialBook, initialChapter, onBibleJump, onCatechismJump }) => {
  const [viewMode, setViewMode] = useState<'library' | 'chapters' | 'reading' | 'search'>('library');
  const [selectedBook, setSelectedBook] = useState<Book | null>(null);
  const [selectedChapter, setSelectedChapter] = useState(1);
  const [targetVerse, setTargetVerse] = useState<number | null>(null);
  const [verses, setVerses] = useState<Verse[]>([]);
  const [loading, setLoading] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');
  const [searchResults, setSearchResults] = useState<UniversalSearchResult[]>([]);
  const [isSearching, setIsSearching] = useState(false);

  const normalize = (text: string) => text.toLowerCase().normalize("NFD").replace(/[\u0300-\u036f]/g, "").trim();

  const filteredBooks = useMemo(() => {
    return CATHOLIC_BIBLE_BOOKS.filter(b => 
      normalize(b.name).includes(normalize(searchTerm)) ||
      normalize(b.category).includes(normalize(searchTerm))
    );
  }, [searchTerm]);

  const handleGlobalSearch = async (e: React.FormEvent) => {
    e.preventDefault();
    if (searchTerm.length < 2) return;

    // 1. Tentar detectar referência (Ex: "João 3:16" ou "1 Corintios 13")
    const refRegex = /^(.+?)\s+(\d+)(?::(\d+))?$/i;
    const match = searchTerm.trim().match(refRegex);

    if (match) {
      const bookName = normalize(match[1]);
      const chapter = parseInt(match[2]);
      const verse = match[3] ? parseInt(match[3]) : null;

      const foundBook = CATHOLIC_BIBLE_BOOKS.find(b => normalize(b.name) === bookName);
      
      if (foundBook && chapter > 0 && chapter <= foundBook.chapters) {
        setSelectedBook(foundBook);
        setSelectedChapter(chapter);
        setTargetVerse(verse);
        setViewMode('reading');
        loadContent(foundBook.name, chapter);
        setSearchTerm('');
        return;
      }
    }

    setIsSearching(true);
    setViewMode('search');
    try {
      const results = await bibleService.searchContent(searchTerm);
      setSearchResults(results);
    } catch (err) {
      console.error(err);
    } finally {
      setIsSearching(false);
    }
  };

  const loadContent = useCallback(async (bookName: string, chapter: number) => {
    setLoading(true);
    try {
      const data = await bibleService.getVerses(bookName, chapter);
      setVerses(data);
    } catch (e) {
      console.error(e);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    if (initialBook) {
      const book = CATHOLIC_BIBLE_BOOKS.find(b => normalize(b.name) === normalize(initialBook));
      if (book) {
        setSelectedBook(book);
        const ch = initialChapter || 1;
        setSelectedChapter(ch);
        setViewMode('reading');
        loadContent(book.name, ch);
      }
    }
  }, [initialBook, initialChapter, loadContent]);

  const handleBookSelect = (book: Book) => {
    setSelectedBook(book);
    setSelectedChapter(1);
    setTargetVerse(null);
    setViewMode('chapters');
  };

  const handleResultClick = (res: UniversalSearchResult) => {
    const parts = res.title.split(' ');
    const bookName = parts.slice(0, -1).join(' ');
    const refParts = parts[parts.length - 1].split(':');
    const chapter = parseInt(refParts[0]);
    const verse = refParts[1] ? parseInt(refParts[1]) : null;
    
    const book = CATHOLIC_BIBLE_BOOKS.find(b => b.name === bookName);
    if (book) {
      setSelectedBook(book);
      setSelectedChapter(chapter);
      setTargetVerse(verse);
      setViewMode('reading');
      loadContent(book.name, chapter);
    }
  };

  return (
    <div className="flex flex-col animate-in fade-in duration-700 min-h-screen">
      
      {viewMode === 'library' && (
        <section className="space-y-12 pb-20">
          <header className="text-center space-y-8">
            <h2 className="text-5xl md:text-[10rem] font-serif font-bold text-stone-900 dark:text-gold tracking-tighter leading-none pt-4">Scriptuarium</h2>
            
            <form onSubmit={handleGlobalSearch} className="max-w-3xl mx-auto px-4">
               <div className="relative group">
                  <Icons.Search className="absolute left-8 top-1/2 -translate-y-1/2 text-gold/40 w-8 h-8 group-focus-within:text-gold transition-all" />
                  <input 
                    type="text" 
                    placeholder="Ref (João 3:16) ou Palavra-chave..." 
                    value={searchTerm}
                    onChange={e => setSearchTerm(e.target.value)}
                    className="w-full pl-20 pr-8 py-8 md:py-10 bg-white dark:bg-stone-900 border border-stone-100 dark:border-stone-800 rounded-[3rem] outline-none font-serif italic text-2xl md:text-3xl shadow-4xl focus:ring-16 focus:ring-gold/5 transition-all"
                  />
                  {searchTerm.length >= 2 && (
                    <button type="submit" className="absolute right-4 top-1/2 -translate-y-1/2 p-5 bg-gold text-stone-900 rounded-full shadow-xl hover:scale-105 transition-all">
                      <Icons.ArrowDown className="w-6 h-6 -rotate-90" />
                    </button>
                  )}
               </div>
            </form>
          </header>

          <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-4 md:gap-8 px-4">
            {filteredBooks.map((book) => (
              <button 
                key={book.id}
                onClick={() => handleBookSelect(book)}
                className="p-8 md:p-12 bg-white dark:bg-stone-900 rounded-[3rem] border border-stone-50 dark:border-stone-800 shadow-xl text-left group hover:border-gold hover:-translate-y-1 transition-all relative overflow-hidden"
              >
                <span className={`text-[8px] md:text-[10px] font-black uppercase tracking-widest mb-4 inline-block px-3 py-1 rounded-full ${book.testament === 'AT' ? 'bg-sacred/10 text-sacred' : 'bg-gold/10 text-gold'}`}>
                  {book.testament === 'AT' ? 'Antigo' : 'Novo'}
                </span>
                <h3 className="text-xl md:text-4xl font-serif font-bold text-stone-900 dark:text-stone-100 group-hover:text-gold transition-colors truncate">{book.name}</h3>
                <p className="text-[10px] text-stone-400 font-black uppercase mt-4 tracking-[0.2em]">{book.chapters} Capítulos</p>
              </button>
            ))}
          </div>
        </section>
      )}

      {viewMode === 'search' && (
        <section className="space-y-12 pb-20 animate-in slide-in-from-bottom-10">
           <header className="flex flex-col items-center gap-6">
              <button onClick={() => setViewMode('library')} className="flex items-center gap-3 text-stone-400 hover:text-gold text-[10px] font-black uppercase tracking-widest">
                <Icons.ArrowDown className="w-4 h-4 rotate-90" /> Voltar à Biblioteca
              </button>
              <h2 className="text-3xl md:text-5xl font-serif font-bold text-stone-900 dark:text-gold">Resultados para "{searchTerm}"</h2>
           </header>

           {isSearching ? (
             <div className="py-24 text-center space-y-4">
                <div className="w-12 h-12 border-4 border-gold border-t-transparent rounded-full animate-spin mx-auto" />
                <p className="font-serif italic text-stone-400 text-xl">Consultando os Profetas e Apóstolos...</p>
             </div>
           ) : searchResults.length > 0 ? (
             <div className="grid gap-6 max-w-4xl mx-auto px-4">
                {searchResults.map((res, i) => (
                  <button 
                    key={i} 
                    onClick={() => handleResultClick(res)}
                    className="w-full text-left p-10 bg-white dark:bg-stone-900 rounded-[3rem] border border-stone-100 dark:border-stone-800 shadow-xl hover:border-gold transition-all group relative overflow-hidden"
                  >
                    <div className="flex justify-between items-start mb-4">
                       <span className="text-[10px] font-black uppercase tracking-widest text-sacred">{res.title}</span>
                       <Icons.Feather className="w-6 h-6 text-gold/20" />
                    </div>
                    <p className="text-xl md:text-2xl font-serif italic text-stone-700 dark:text-stone-300 leading-relaxed">"{res.snippet}"</p>
                    <div className="mt-6 flex justify-end">
                       <span className="text-[8px] font-black uppercase text-gold group-hover:underline">Ler no contexto →</span>
                    </div>
                  </button>
                ))}
             </div>
           ) : (
             <div className="text-center py-24 opacity-30">
                <Icons.Cross className="w-16 h-16 mx-auto mb-6" />
                <p className="text-2xl font-serif italic">Nenhuma passagem encontrada.</p>
             </div>
           )}
        </section>
      )}

      {viewMode === 'chapters' && selectedBook && (
        <section className="space-y-12 pb-20 animate-in fade-in">
           <button onClick={() => setViewMode('library')} className="group flex items-center gap-3 text-stone-400 hover:text-gold text-[10px] font-black uppercase tracking-widest pt-4">
             <Icons.ArrowDown className="w-4 h-4 rotate-90" /> Voltar
           </button>
           <header className="text-center">
              <h2 className="text-6xl md:text-9xl font-serif font-bold text-stone-900 dark:text-stone-100 tracking-tighter leading-none">{selectedBook.name}</h2>
           </header>
           <div className="grid grid-cols-4 sm:grid-cols-6 md:grid-cols-10 gap-3 max-w-4xl mx-auto px-4">
              {Array.from({ length: selectedBook.chapters }).map((_, i) => (
                <button 
                  key={i}
                  onClick={() => { setSelectedChapter(i + 1); setTargetVerse(null); setViewMode('reading'); loadContent(selectedBook.name, i + 1); }}
                  className="aspect-square bg-white dark:bg-stone-900 border border-stone-100 dark:border-stone-800 rounded-2xl flex items-center justify-center font-serif text-2xl font-bold hover:bg-gold hover:text-stone-900 transition-all shadow-lg"
                >
                  {i + 1}
                </button>
              ))}
           </div>
        </section>
      )}

      {viewMode === 'reading' && selectedBook && (
        <section className="space-y-8 animate-in fade-in duration-1000 pb-32">
           <header className="flex items-center justify-between px-4 pt-4">
              <button onClick={() => setViewMode('chapters')} className="p-4 bg-stone-50 dark:bg-stone-900 rounded-full text-stone-400 hover:text-gold transition-all shadow-md">
                <Icons.ArrowDown className="w-6 h-6 rotate-90" />
              </button>
              <div className="text-center space-y-1">
                 <span className="text-[10px] font-black uppercase tracking-[0.4em] text-gold">{selectedBook.category}</span>
                 <h3 className="text-2xl font-serif font-bold">{selectedBook.name} {selectedChapter}</h3>
              </div>
              <div className="w-12" />
           </header>

           {loading ? (
             <div className="py-40 text-center space-y-6">
                <div className="w-12 h-12 border-4 border-gold border-t-transparent rounded-full animate-spin mx-auto" />
                <p className="text-xl font-serif italic text-stone-400">Carregando Escrituras...</p>
             </div>
           ) : (
             <div className="contents px-4">
               <BibleReader 
                 book={selectedBook.name} 
                 chapter={selectedChapter} 
                 verses={verses} 
                 initialVerse={targetVerse}
                 onBibleJump={onBibleJump}
                 onCatechismJump={onCatechismJump}
               />
               <ChapterNavigation 
                 prev={selectedChapter > 1 ? selectedChapter - 1 : null}
                 next={selectedChapter < selectedBook.chapters ? selectedChapter + 1 : null}
                 onNavigate={(ch) => { setSelectedChapter(ch); setTargetVerse(null); loadContent(selectedBook.name, ch); }}
               />
             </div>
           )}
        </section>
      )}
    </div>
  );
};

export default Bible;
