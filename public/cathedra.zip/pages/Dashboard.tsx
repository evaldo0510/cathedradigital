
import React from 'react';
import { AppRoute, User } from '../types';
import { Icons, Logo } from '../constants';
import { BookOpen, Scroll, ShieldCheck, Award, History, Heart, Feather, Star } from 'lucide-react';
import UnifiedSearch from '../components/UnifiedSearch';

interface DashboardProps {
  onSearch: (t: string) => void;
  user: User | null;
  onNavigate: (r: AppRoute) => void;
  openBible: () => void;
  openCatechism: () => void;
  openDocs: () => void;
}

const Dashboard: React.FC<DashboardProps> = ({ onNavigate, onSearch, openBible, openCatechism, openDocs }) => {
  return (
    <div className="space-y-32 animate-fade-in bg-[#0c0a09] -mt-10 pt-10">
      {/* HERO SECTION STUDIUM */}
      <header className="max-w-6xl mx-auto text-center px-4">
        <div className="mb-24">
          <div className="inline-flex items-center gap-3 px-6 py-3 rounded-full bg-white/5 border border-gold/20 shadow-premium text-gold text-[10px] font-black uppercase tracking-widest mb-12">
            <Star size={14} className="text-gold animate-pulse fill-current" /> 
            Escritura • Tradição • Magistério
          </div>
          <h1 className="text-6xl md:text-9xl font-serif font-bold text-white mb-12 leading-[0.9] tracking-tighter uppercase">
            A Verdade <br /> <span className="text-gold italic drop-shadow-2xl">não muda.</span>
          </h1>
          <p className="text-xl md:text-2xl text-stone-400 mb-20 leading-relaxed font-serif italic max-w-3xl mx-auto">
            A inteligência teológica a serviço da fé. Um ecossistema imersivo para a formação intelectual do fiel católico.
          </p>
          
          <div className="relative z-[110]">
            <UnifiedSearch onSelectResult={(type, data) => onSearch(data.title || data.text || data.content)} />
          </div>
        </div>
      </header>

      {/* BIG 3 CARDS - AS FONTES */}
      <section className="space-y-16 px-4">
        <div className="text-center">
           <h2 className="text-[10px] font-black uppercase tracking-[0.6em] text-stone-600 mb-4">Depositum Fidei</h2>
           <h3 className="text-4xl md:text-6xl font-serif font-bold text-white uppercase">As Fontes da Revelação</h3>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 max-w-6xl mx-auto">
          {[
            { id: 'escritura', t: 'Escritura', c: 'bg-sacred', i: BookOpen, d: 'O Verbo revelado nos textos sagrados. A alma da Teologia.', action: openBible, border: 'border-sacred/30' },
            { id: 'tradicao', t: 'Tradição', c: 'bg-gold', i: Scroll, d: 'A síntese sistemática da nossa herança. O mapa seguro.', action: openCatechism, border: 'border-gold/30', iconColor: 'text-stone-900' },
            { id: 'magisterio', t: 'Magistério', c: 'bg-stone-800', i: ShieldCheck, d: 'A voz firme da Igreja em comunhão com Pedro.', action: openDocs, border: 'border-stone-700' }
          ].map(p => (
            <div 
              key={p.id} 
              onClick={p.action} 
              className={`p-12 bg-white/5 backdrop-blur-md rounded-[4rem] border ${p.border} cursor-pointer text-center group hover:bg-white/10 transition-all duration-700 transform hover:-translate-y-3 shadow-2xl`}
            >
              <div className={`w-20 h-20 ${p.c} ${p.iconColor || 'text-white'} rounded-3xl flex items-center justify-center mb-10 mx-auto shadow-sacred group-hover:rotate-12 transition-transform`}>
                <p.i size={38} />
              </div>
              <h3 className="text-4xl font-serif font-bold mb-6 text-white uppercase">{p.t}</h3>
              <p className="text-stone-400 text-base leading-relaxed mb-12 h-12 font-serif italic">{p.d}</p>
              <span className="text-[10px] font-black text-gold uppercase tracking-[0.3em] group-hover:underline">Explorar Fontes →</span>
            </div>
          ))}
        </div>
      </section>

      {/* CALL TO ACTION FORMAÇÃO */}
      <section className="px-4">
        <div className="bg-gradient-to-br from-sacred/40 via-stone-900 to-stone-950 py-24 md:py-32 rounded-[6rem] border border-gold/10 relative overflow-hidden group shadow-4xl max-w-6xl mx-auto">
           <Icons.Cross className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[40rem] h-[40rem] text-gold/5 rotate-12 pointer-events-none" />
           <div className="max-w-4xl mx-auto px-6 text-center space-y-12 relative z-10">
              <span className="text-[10px] font-black uppercase tracking-[0.6em] text-gold">Caminhos Pedagógicos</span>
              <h2 className="text-5xl md:text-8xl font-serif font-bold text-white tracking-tighter leading-tight uppercase">Uma jornada de <br /><span className="text-gold italic drop-shadow-md">maturidade espiritual.</span></h2>
              <p className="text-xl md:text-2xl text-stone-300 font-serif leading-relaxed italic max-w-2xl mx-auto opacity-80">
                Não estude de forma isolada. Siga percursos desenhados para uma compreensão orgânica da fé católica.
              </p>
              <div className="pt-6">
                <button 
                  onClick={() => onNavigate(AppRoute.TRILHAS)}
                  className="px-16 py-7 bg-gold text-stone-900 rounded-full font-black uppercase text-xs tracking-widest shadow-sacred hover:scale-105 hover:bg-white transition-all active:scale-95"
                >
                  Ver Caminhos de Formação
                </button>
              </div>
           </div>
        </div>
      </section>

      <footer className="text-center pb-20 opacity-20 group">
         <Logo className="w-16 h-16 mx-auto mb-8 group-hover:rotate-180 transition-transform duration-[4s] grayscale brightness-200" />
         <p className="text-[12px] font-black uppercase tracking-[1em] text-white">Ad Maiorem Dei Gloriam</p>
      </footer>
    </div>
  );
};

export default Dashboard;
