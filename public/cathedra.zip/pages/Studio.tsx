
import React, { useState, useEffect } from 'react';
import { Icons } from '../constants';
import { GoogleGenAI } from "@google/genai";

const Studio: React.FC = () => {
  const [renderUrl, setRenderUrl] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const generateRender = async () => {
    setLoading(true);
    setError(null);
    
    // Check if API key is needed and selected (Mandatory check before using nano banana image models in some contexts)
    if (window.aistudio && !(await window.aistudio.hasSelectedApiKey())) {
      await window.aistudio.openSelectKey();
    }

    // Always create a new instance right before the call to get the latest key
    const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
    
    try {
      const response = await ai.models.generateContent({
        model: 'gemini-2.5-flash-image',
        contents: {
          parts: [
            {
              text: 'Photorealistic 3D render of a luxury bishop chair (Cathedra), solid white oak wood, classical gothic style, crimson velvet upholstery, intricate wood carvings, professional studio lighting, 8k resolution, furniture catalog style.',
            },
          ],
        },
        config: {
          imageConfig: {
            aspectRatio: "3:4"
          }
        }
      });

      let foundImage = false;
      if (response.candidates && response.candidates[0].content.parts) {
        for (const part of response.candidates[0].content.parts) {
          if (part.inlineData) {
            const base64 = part.inlineData.data;
            setRenderUrl(`data:image/png;base64,${base64}`);
            foundImage = true;
            break;
          }
        }
      }
      
      if (!foundImage) {
        setError("Não foi possível extrair o render do projeto.");
      }
    } catch (err: any) {
      console.error("Erro no render:", err);
      
      if (err.message?.includes("Requested entity was not found.")) {
        setError("Chave de API não encontrada ou inválida. Por favor, selecione novamente.");
        if (window.aistudio?.openSelectKey) {
          await window.aistudio.openSelectKey();
        }
      } else {
        setError("Erro ao materializar o 3D. Verifique sua conexão.");
      }
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    generateRender();
  }, []);

  return (
    <div className="max-w-6xl mx-auto space-y-12 pb-32 animate-in fade-in duration-1000">
      <header className="text-center space-y-4">
        <div className="inline-flex items-center gap-3 px-4 py-1.5 bg-gold/10 border border-gold/20 rounded-full">
          <Icons.Feather className="w-4 h-4 text-gold" />
          <span className="text-[10px] font-black uppercase tracking-widest text-gold">Studio YARA • Design & Marcenaria</span>
        </div>
        <h2 className="text-5xl md:text-8xl font-serif font-bold text-stone-900 dark:text-stone-100 tracking-tighter leading-none">Materializando a Fé</h2>
        <p className="text-stone-400 italic text-xl md:text-2xl font-serif max-w-2xl mx-auto">
          "Onde a beleza da forma encontra a precisão do corte."
        </p>
      </header>

      <div className="grid lg:grid-cols-2 gap-12 items-start">
        {/* Render Visualization */}
        <section className="bg-white dark:bg-stone-900 rounded-[4rem] overflow-hidden shadow-4xl border border-stone-100 dark:border-stone-800 group">
          <div className="aspect-[3/4] relative bg-stone-50 dark:bg-stone-950">
            {loading ? (
              <div className="absolute inset-0 flex flex-col items-center justify-center space-y-6">
                <div className="w-16 h-16 border-4 border-gold border-t-transparent rounded-full animate-spin" />
                <p className="font-serif italic text-stone-400 text-lg">YARA está esculpindo o 3D...</p>
              </div>
            ) : renderUrl ? (
              <img src={renderUrl} alt="Cátedra Render" className="w-full h-full object-cover animate-in zoom-in-95 duration-1000" />
            ) : error ? (
              <div className="absolute inset-0 flex flex-col items-center justify-center p-8 text-center space-y-4">
                <Icons.Cross className="w-12 h-12 text-sacred/40" />
                <p className="font-serif italic text-sacred/60">{error}</p>
                <button onClick={generateRender} className="px-6 py-2 bg-sacred/10 text-sacred rounded-full text-xs font-bold uppercase tracking-widest hover:bg-sacred hover:text-white transition-all">Tentar Novamente</button>
              </div>
            ) : null}
          </div>
          <div className="p-10 border-t border-stone-50 dark:border-stone-800 flex justify-between items-center">
            <div>
              <h3 className="text-2xl font-serif font-bold">Cátedra Episcopal v1</h3>
              <p className="text-gold font-serif italic">Carvalho Branco & Veludo</p>
            </div>
            <button onClick={generateRender} className="p-4 bg-stone-100 dark:bg-stone-800 rounded-2xl hover:text-gold transition-colors active:scale-95">
              <Icons.History className="w-6 h-6" />
            </button>
          </div>
        </section>

        {/* Technical Details */}
        <aside className="space-y-8">
          <div className="p-10 bg-stone-900 text-white rounded-[3.5rem] shadow-2xl relative overflow-hidden">
             <Icons.Cross className="absolute -bottom-10 -right-10 w-48 h-48 opacity-[0.03] text-gold" />
             <h4 className="text-[11px] font-black uppercase tracking-[0.5em] text-gold mb-8">Memória Descritiva</h4>
             <div className="space-y-6">
                <div className="flex justify-between border-b border-white/10 pb-4">
                  <span className="text-stone-400 text-sm uppercase font-bold">Espécie</span>
                  <span className="font-serif font-bold text-lg">Carvalho Europeu</span>
                </div>
                <div className="flex justify-between border-b border-white/10 pb-4">
                  <span className="text-stone-400 text-sm uppercase font-bold">Encaixes</span>
                  <span className="font-serif font-bold text-lg">Fura e Respiga</span>
                </div>
                <div className="flex justify-between border-b border-white/10 pb-4">
                  <span className="text-stone-400 text-sm uppercase font-bold">Acabamento</span>
                  <span className="font-serif font-bold text-lg">Verniz PU Fosco</span>
                </div>
                <div className="flex justify-between border-b border-white/10 pb-4">
                  <span className="text-stone-400 text-sm uppercase font-bold">Estofado</span>
                  <span className="font-serif font-bold text-lg">Veludo Carmesim D33</span>
                </div>
             </div>
          </div>

          <div className="bg-white dark:bg-stone-900 p-10 rounded-[3.5rem] border border-stone-100 dark:border-stone-800 shadow-xl">
             <h4 className="text-lg font-serif font-bold mb-6 flex items-center gap-3">
               <Icons.Layout className="w-5 h-5 text-sacred" />
               Ações do Marceneiro
             </h4>
             <div className="grid gap-4">
                <button className="w-full py-5 bg-stone-50 dark:bg-stone-800 rounded-2xl font-black uppercase tracking-widest text-[10px] hover:border-gold border border-transparent transition-all text-left px-8 flex items-center justify-between group">
                  Solicitar Plano de Corte
                  <Icons.ArrowDown className="w-4 h-4 -rotate-90 group-hover:translate-x-1 transition-transform" />
                </button>
                <button className="w-full py-5 bg-stone-50 dark:bg-stone-800 rounded-2xl font-black uppercase tracking-widest text-[10px] hover:border-gold border border-transparent transition-all text-left px-8 flex items-center justify-between group">
                  Exportar Lista de Materiais
                  <Icons.ArrowDown className="w-4 h-4 -rotate-90 group-hover:translate-x-1 transition-transform" />
                </button>
                <button className="w-full py-6 bg-gold text-stone-900 rounded-2xl font-black uppercase tracking-widest text-[10px] shadow-xl hover:scale-[1.02] transition-all">
                  Gerar Orçamento Executivo
                </button>
             </div>
          </div>

          <div className="p-8 bg-sacred/5 border border-sacred/20 rounded-3xl">
             <p className="text-sm font-serif italic text-sacred leading-relaxed">
               "Oi! Sou a YARA. Analisei o rascunho da sua Cátedra e este render fotorrealista mantém a fidelidade absoluta aos montantes de carvalho maciço solicitados. O projeto está otimizado para execução com encaixes tradicionais."
             </p>
          </div>
        </aside>
      </div>
    </div>
  );
};

export default Studio;
