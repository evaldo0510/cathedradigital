
export const documentsData = [
  {
    "name": "Lumen Gentium",
    "year": "1964",
    "paragraphs": [
      "A Igreja é o povo de Deus, chamada a testemunhar Cristo em todas as nações.",
      "Como ensina o Catecismo (CIC 1), fomos criados para participar da vida divina.",
      "A criação é o palco da glória de Deus (Cf. Genesis 1:1)."
    ]
  },
  {
    "name": "Dei Verbum",
    "year": "1965",
    "paragraphs": [
      "A Sagrada Escritura é a palavra de Deus enquanto é redigida sob a inspiração do Espírito Divino.",
      "A economia da Revelação realiza-se por meio de ações e palavras (Cf. CIC 2).",
      "No princípio era o Verbo e o Verbo se fez carne."
    ]
  }
];
