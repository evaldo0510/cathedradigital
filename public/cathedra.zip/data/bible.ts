
export const bibleData: Record<string, Record<string, Record<string, string>>> = {
  "Genesis": {
    "1": {
      "1": "No princípio Deus criou os céus e a terra.",
      "2": "A terra era sem forma e vazia; as trevas cobriam o abismo e o Espírito de Deus pairava sobre as águas.",
      "27": "Deus criou o homem à sua imagem, criou-o à imagem de Deus, criou o homem e a mulher."
    },
    "2": {
      "1": "Assim foram concluídos os céus e a terra, com todo o seu exército."
    }
  },
  "Exodo": {
    "1": {
      "1": "Estes são os nomes dos filhos de Israel que foram para o Egito com Jacó."
    }
  }
};
