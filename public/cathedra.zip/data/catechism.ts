
export const catechismData = [
  {
    "part": "Parte 1 – Profissão de Fé",
    "paragraphs": [
      { "number": 1, "text": "Deus, infinitamente perfeito e bem-aventurado em Si mesmo, em um desígnio de pura bondade, criou livremente o homem para fazê-lo participar de sua vida bem-aventurada.", "context": "Vida do Homem" },
      { "number": 2, "text": "Em todos os tempos e em todos os lugares, Deus está perto do homem. Ele o chama e o ajuda a procurá-lo, a conhecê-lo e a amá-lo com todas as suas forças.", "context": "Busca de Deus" },
      { "number": 27, "text": "O desejo de Deus está inscrito no coração do homem, pois o homem foi criado por Deus e para Deus (Cf. Genesis 1:27).", "context": "Desejo de Infinito" }
    ]
  },
  {
    "part": "Parte 2 – Celebração do Mistério",
    "paragraphs": [
      { "number": 1066, "text": "No Símbolo da fé, a Igreja confessa o mistério da Santíssima Trindade e o seu 'desígnio benevolente' sobre toda a criação.", "context": "Liturgia" }
    ]
  }
];
