/**
 * Cathedra Digital - Service Worker v18.1 (Stable URL Handling)
 */

const CACHE_NAME = 'cathedra-v18-prod';
const STATIC_ASSETS = [
  './',
  './index.html',
  './metadata.json',
  'https://fonts.googleapis.com/css2?family=Inter:wght@400;600;700;900&family=Playfair+Display:ital,wght@0,400;0,700;1,400&display=swap'
];

self.addEventListener('install', (event) => {
  event.waitUntil(
    caches.open(CACHE_NAME).then((cache) => cache.addAll(STATIC_ASSETS))
  );
  self.skipWaiting();
});

self.addEventListener('activate', (event) => {
  event.waitUntil(
    caches.keys().then((keys) => Promise.all(
      keys.filter(key => key !== CACHE_NAME).map(key => caches.delete(key))
    ))
  );
  self.clients.claim();
});

self.addEventListener('fetch', (event) => {
  // Ignorar protocolos que não sejam http ou https (ex: chrome-extension, data)
  if (!event.request.url.startsWith('http')) return;

  let url;
  try {
    url = new URL(event.request.url);
  } catch (e) {
    return; // Silently skip invalid URLs
  }

  // 1. NETWORK-FIRST: Para APIs de IA e Supabase
  if (url.hostname.includes('googleapis.com') || url.hostname.includes('supabase.co')) {
    event.respondWith(
      fetch(event.request)
        .catch(() => caches.match(event.request))
    );
    return;
  }

  // 2. STALE-WHILE-REVALIDATE: Para o HTML principal e Shell do App
  if (event.request.mode === 'navigate') {
    event.respondWith(
      caches.match('./index.html').then((cachedResponse) => {
        const fetchPromise = fetch('./index.html').then((networkResponse) => {
          caches.open(CACHE_NAME).then((cache) => cache.put('./index.html', networkResponse.clone()));
          return networkResponse;
        });
        return cachedResponse || fetchPromise;
      })
    );
    return;
  }

  // 3. CACHE-FIRST: Para imagens e fontes (ativos estáticos)
  event.respondWith(
    caches.match(event.request).then((cachedResponse) => {
      if (cachedResponse) return cachedResponse;
      return fetch(event.request).then((networkResponse) => {
        const cloned = networkResponse.clone();
        caches.open(CACHE_NAME).then((cache) => cache.put(event.request, cloned));
        return networkResponse;
      });
    })
  );
});