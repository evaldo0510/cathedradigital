
import React, { useState, useEffect, createContext, useMemo } from 'react';
import { ShieldCheck, X, BookOpen, Scroll, Star, Menu, Award, Globe, Heart, Search, Users } from 'lucide-react';
import Sidebar from './components/Sidebar';
import Footer from './components/Footer';
import Dashboard from './pages/Dashboard';
import Bible from './pages/Bible';
import Catechism from './pages/Catechism';
import Magisterium from './pages/Magisterium';
import Profile from './pages/Profile';
import Login from './pages/Login';
import Checkout from './pages/Checkout';
import Tracks from './pages/Tracks';
import Favorites from './pages/Favorites';
import StudyMode from './pages/StudyMode';
import Saints from './pages/Saints';
import DailyLiturgy from './pages/DailyLiturgy';
import Rosary from './pages/Rosary';
import ViaCrucis from './pages/ViaCrucis';
import Poenitentia from './pages/Poenitentia';
import Prayers from './pages/Prayers';
import Breviary from './pages/Breviary';
import Missal from './pages/Missal';
import Certamen from './pages/Certamen';
import AquinasOpera from './pages/AquinasOpera';
import About from './pages/About';

import BibleModal from './components/BibleModal';
import CatechismModal from './components/CatechismModal';
import DocumentsModal from './components/DocumentsModal';
import PersonalPrayerModal from './components/PersonalPrayerModal';
import OfflineIndicator from './components/OfflineIndicator';

import { AppRoute, User, Language, StudyResult } from './types';
import { useOfflineMode } from './hooks/useOfflineMode';
import { getIntelligentStudy } from './services/gemini';
import { UI_TRANSLATIONS } from './services/translations';

export const LangContext = createContext<any>(null);

const App: React.FC<{ installPrompt: any, onInstall: () => void }> = ({ installPrompt, onInstall }) => {
  const [lang, setLang] = useState<Language>('pt');
  const [route, setRoute] = useState<AppRoute>(AppRoute.DASHBOARD);
  const [user, setUser] = useState<User | null>(null);
  const [monastery, setMonastery] = useState(false);
  const [scrolled, setScrolled] = useState(false);
  
  const [bibleOpen, setBibleOpen] = useState(false);
  const [catechismOpen, setCatechismOpen] = useState(false);
  const [docsOpen, setDocsOpen] = useState(false);
  const [prayerModalOpen, setPrayerModalOpen] = useState(false);

  const [bibleTarget, setBibleTarget] = useState<{book: string, chapter: number, verse: number} | null>(null);
  const [catechismTarget, setCatechismTarget] = useState<number | null>(null);
  const [activeStudy, setActiveStudy] = useState<StudyResult | null>(null);

  const [isSidebarOpen, setIsSidebarOpen] = useState(false);
  const connectivity = useOfflineMode();

  const t = useMemo(() => (key: string) => {
    return UI_TRANSLATIONS[lang]?.[key] || UI_TRANSLATIONS['en']?.[key] || key;
  }, [lang]);

  useEffect(() => {
    const savedUser = localStorage.getItem('cathedra_user');
    if (savedUser) setUser(JSON.parse(savedUser));

    const handleScroll = () => setScrolled(window.scrollY > 20);
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const handleNavigate = (r: AppRoute) => {
    setRoute(r);
    setMonastery(false);
    setIsSidebarOpen(false);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleBibleJump = (book: string, chapter: number, verse: number) => {
    setBibleTarget({ book, chapter, verse });
    setBibleOpen(true);
  };

  const handleCatechismJump = (para: number) => {
    setCatechismTarget(para);
    setCatechismOpen(true);
  };

  const handleDeepStudy = async (topic: string) => {
    setRoute(AppRoute.STUDY_MODE);
    setActiveStudy(null);
    const result = await getIntelligentStudy(topic, lang);
    setActiveStudy(result);
  };

  return (
    <LangContext.Provider value={{ lang, setLang, t, user, installPrompt, handleInstall: onInstall }}>
      <div className={`min-h-screen transition-all duration-1000 ${monastery ? 'bg-[#F4F1EC] text-[#4A3728] font-serif' : 'bg-[#0c0a09] text-stone-300 font-sans'}`}>
        <OfflineIndicator state={connectivity} />

        <BibleModal isOpen={bibleOpen} onClose={() => { setBibleOpen(false); setBibleTarget(null); }} initialState={bibleTarget} />
        <CatechismModal isOpen={catechismOpen} onClose={() => { setCatechismOpen(false); setCatechismTarget(null); }} onBibleJump={handleBibleJump} targetPara={catechismTarget} />
        <DocumentsModal isOpen={docsOpen} onClose={() => setDocsOpen(false)} onBibleJump={handleBibleJump} onCatechismJump={handleCatechismJump} />
        <PersonalPrayerModal isOpen={prayerModalOpen} onClose={() => setPrayerModalOpen(false)} />

        {!monastery && (
          <nav className={`fixed top-0 w-full z-[140] transition-all duration-700 ${scrolled ? 'bg-[#0c0a09]/90 backdrop-blur-2xl border-b border-white/5 shadow-premium py-4 md:py-5' : 'bg-transparent py-8 md:py-10'} px-6 md:px-12 flex justify-between items-center`}>
             <div onClick={() => handleNavigate(AppRoute.DASHBOARD)} className="flex items-center gap-4 cursor-pointer group">
                <div className="w-11 h-11 bg-stone-900 dark:bg-gold rounded-2xl flex items-center justify-center text-white dark:text-stone-900 shadow-2xl group-hover:rotate-12 transition-all border border-white/10">
                   <ShieldCheck size={26} />
                </div>
                <div className="hidden sm:block">
                  <span className="text-2xl font-serif font-black tracking-tighter block leading-none dark:text-white uppercase">CATHEDRA</span>
                  <span className="text-[9px] font-bold tracking-[0.3em] text-gold uppercase">Digital Sanctuarium</span>
                </div>
             </div>
             
             <div className="hidden lg:flex items-center gap-12">
                {[
                  { label: 'Nártex', route: AppRoute.DASHBOARD },
                  { label: 'Liturgia', route: AppRoute.DAILY_LITURGY },
                  { label: 'Bíblia', route: AppRoute.BIBLE },
                  { label: 'Catecismo', route: AppRoute.CATECHISM }
                ].map(item => (
                  <button 
                    key={item.label}
                    onClick={() => handleNavigate(item.route)} 
                    className={`text-[10px] font-black uppercase tracking-[0.2em] transition-all duration-300 relative group
                      ${route === item.route ? 'text-gold' : 'text-stone-500 hover:text-gold'}`}
                  >
                    {item.label}
                    <div className={`absolute -bottom-2 left-0 w-full h-[2px] bg-gold transition-all duration-500 origin-left scale-x-0 group-hover:scale-x-100 ${route === item.route ? 'scale-x-100' : ''}`} />
                  </button>
                ))}
                
                <div className="w-px h-6 bg-white/10 mx-2" />
                
                <button 
                  onClick={() => setMonastery(true)} 
                  className="px-8 py-3 bg-white/5 text-gold rounded-2xl border border-gold/30 text-[10px] font-black hover:bg-gold hover:text-stone-900 transition-all shadow-xl backdrop-blur-sm hover:scale-105 active:scale-95"
                >
                  MODO MOSTEIRO
                </button>
             </div>

             <button onClick={() => setIsSidebarOpen(true)} className="lg:hidden p-3 text-stone-400 hover:text-gold transition-colors bg-white/5 rounded-xl">
                <Menu size={26} />
             </button>
          </nav>
        )}

        <div className={`fixed inset-0 z-[150] transition-all ${isSidebarOpen ? 'opacity-100' : 'pointer-events-none opacity-0'}`}>
          <div className="absolute inset-0 bg-black/95 backdrop-blur-xl" onClick={() => setIsSidebarOpen(false)} />
          <div className={`relative h-full w-80 transition-transform duration-500 ${isSidebarOpen ? 'translate-x-0' : '-translate-x-full'}`}>
            <Sidebar 
              currentPath={route} 
              onNavigate={handleNavigate} 
              onOpenQuickBible={() => setBibleOpen(true)} 
              onOpenQuickDocs={() => setDocsOpen(true)}
              onOpenQuickCIC={() => setCatechismOpen(true)}
              onOpenPersonalPrayer={() => setPrayerModalOpen(true)}
              onClose={() => setIsSidebarOpen(false)} 
              user={user} 
            />
          </div>
        </div>

        <main className={monastery ? 'pt-24 pb-40' : 'pt-36 md:pt-52 pb-40 px-4 md:px-10'}>
          {monastery ? (
             <div className="max-w-2xl mx-auto animate-fade-in text-center py-20">
               <h2 className="text-gold font-serif italic text-3xl mb-16 opacity-50 uppercase tracking-widest">Lectio Divina</h2>
               <article className="prose prose-stone dark:prose-invert prose-2xl mx-auto italic text-4xl text-stone-800 dark:text-stone-200 leading-[1.8] font-serif selection:bg-gold/30">
                 "No princípio era o <span className="font-bold border-b-2 border-gold/40 text-gold">Verbo</span>, e o Verbo estava junto de Deus, e o Verbo era Deus."
               </article>
               <div className="mt-40 pt-12 border-t border-gold/20 text-[11px] font-black uppercase tracking-[0.6em] text-gold/40">Oração • Silêncio • Contemplação</div>
             </div>
          ) : (
            <div className="max-w-7xl mx-auto">
              {route === AppRoute.DASHBOARD && <Dashboard onNavigate={handleNavigate} user={user} onSearch={handleDeepStudy} openBible={() => handleNavigate(AppRoute.BIBLE)} openCatechism={() => handleNavigate(AppRoute.CATECHISM)} openDocs={() => handleNavigate(AppRoute.MAGISTERIUM)} />}
              {route === AppRoute.DAILY_LITURGY && <DailyLiturgy />}
              {route === AppRoute.BIBLE && <Bible onBibleJump={handleBibleJump} onCatechismJump={handleCatechismJump} />}
              {route === AppRoute.CATECHISM && <Catechism onDeepDive={handleDeepStudy} onBibleJump={handleBibleJump} onCatechismJump={handleCatechismJump} />}
              {route === AppRoute.MAGISTERIUM && <Magisterium />}
              {route === AppRoute.TRILHAS && <Tracks onNavigateBible={handleBibleJump} onNavigateCIC={handleCatechismJump} userId={user?.id} />}
              {route === AppRoute.FAVORITES && <Favorites />}
              {route === AppRoute.STUDY_MODE && <StudyMode data={activeStudy} onSearch={handleDeepStudy} />}
              {route === AppRoute.SAINTS && <Saints />}
              {route === AppRoute.ROSARY && <Rosary />}
              {route === AppRoute.VIA_CRUCIS && <ViaCrucis />}
              {route === AppRoute.POENITENTIA && <Poenitentia />}
              {route === AppRoute.PRAYERS && <Prayers />}
              {route === AppRoute.BREVIARY && <Breviary />}
              {route === AppRoute.MISSAL && <Missal />}
              {route === AppRoute.CERTAMEN && <Certamen />}
              {route === AppRoute.AQUINAS_OPERA && <AquinasOpera />}
              {route === AppRoute.ABOUT && <About />}
              {route === AppRoute.PROFILE && user && <Profile user={user} onLogout={() => { setUser(null); localStorage.removeItem('cathedra_user'); setRoute(AppRoute.DASHBOARD); }} onSelectStudy={setActiveStudy} onNavigateCheckout={() => handleNavigate(AppRoute.CHECKOUT)} />}
              {route === AppRoute.LOGIN && <Login onLogin={(u) => { setUser(u); setRoute(AppRoute.DASHBOARD); }} />}
              {route === AppRoute.CHECKOUT && <Checkout onBack={() => handleNavigate(AppRoute.DASHBOARD)} />}
            </div>
          )}
        </main>

        {!monastery && (
          <Footer 
            onNavigate={handleNavigate} 
            onOpenBible={() => setBibleOpen(true)} 
            onOpenCatechism={() => setCatechismOpen(true)} 
            onOpenDocs={() => setDocsOpen(true)} 
          />
        )}
      </div>
    </LangContext.Provider>
  );
};

export default App;
