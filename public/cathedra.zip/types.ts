
export type Language = 'pt' | 'en' | 'es' | 'la' | 'it' | 'fr' | 'de';

export enum AppRoute {
  DASHBOARD = '/',
  BIBLE = '/bible',
  CATECHISM = '/catechism',
  MAGISTERIUM = '/magisterium',
  TRILHAS = '/tracks',
  FAVORITES = '/favorites',
  DAILY_LITURGY = '/daily-liturgy',
  STUDY_MODE = '/study',
  AQUINAS_OPERA = '/aquinas-opera',
  CERTAMEN = '/certamen',
  PROFILE = '/profile',
  LOGIN = '/login',
  CHECKOUT = '/checkout',
  SAINTS = '/saints',
  ROSARY = '/rosary',
  VIA_CRUCIS = '/via-crucis',
  POENITENTIA = '/poenitentia',
  PRAYERS = '/prayers',
  BREVIARY = '/breviary',
  MISSAL = '/missal',
  ABOUT = '/about'
}

export interface Verse {
  book: string;
  chapter: number;
  verse: number;
  text: string;
}

export interface CatechismParagraph {
  number: number;
  content: string;
  context: string;
}

export interface MagisteriumDoc {
  title: string;
  source: string;
  year: string;
  summary: string;
  arquivo?: string;
}

export interface StudyResult {
  topic: string;
  summary: string;
  bibleVerses: Verse[];
  catechismParagraphs: CatechismParagraph[];
  magisteriumDocs?: MagisteriumDoc[];
  saintsQuotes?: string[];
}

export interface SavedItem {
  id: string;
  type: 'verse' | 'catechism' | 'study' | 'prayer' | 'liturgy' | 'aquinas';
  title: string;
  content: string;
  timestamp: string;
  metadata?: any;
}

export interface Saint {
  name: string;
  feastDay: string;
  patronage: string;
  biography: string;
  image: string;
  quote?: string;
}

export interface ThomisticArticle {
  reference: string;
  articleTitle: string;
  objections: { id: number; text: string }[];
  respondeo: string;
}

export interface Dogma {
  title: string;
  definition: string;
  council?: string;
  year?: string;
  tags?: string[];
  period?: string;
  sourceUrl?: string;
}

export interface LiturgyInfo {
  color: 'green' | 'purple' | 'white' | 'red' | 'rose' | 'black';
  season: string;
  rank: string;
  date: string;
  dayName: string;
  cycle: string;
  week?: string;
}

export interface Gospel {
  reference: string;
  text: string;
  reflection?: string;
}

export interface QuizQuestion {
  id: string;
  question: string;
  options: string[];
  correctAnswer: number;
  explanation: string;
  category: string;
  difficulty: string;
}

export interface UniversalSearchResult {
  id: string;
  type: string;
  title: string;
  snippet: string;
  source: {
    name: string;
    code: string;
    reliability?: string;
  };
  relevance: number;
}

export interface DailyLiturgyContent {
  date: string;
  collect: string;
  firstReading: {
    reference: string;
    text: string;
  };
  psalm: {
    title: string;
    text: string;
  };
  gospel: Gospel;
}

export interface Prayer {
  id: string;
  title: string;
  latin?: string;
  vernacular: string;
  category: 'daily' | 'marian' | 'latin' | 'custom';
}

export interface AquinasWork {
  id: string;
  title: string;
  category: 'summa' | 'disputed' | 'commentary' | 'opuscula';
  description: string;
  parts: string[];
}

export interface TrackStep {
  type: 'biblia' | 'cic' | 'documento' | 'video' | 'audio';
  ref: string;
  label?: string;
}

export interface TrackModule {
  id: string;
  title: string;
  content: TrackStep[];
}

export interface LearningTrack {
  id: string;
  title: string;
  description: string;
  level: 'Iniciante' | 'Intermediário' | 'Avançado';
  icon: string;
  image?: string;
  modules: TrackModule[];
}

export interface User {
  id: string;
  name: string;
  email: string;
  role: 'admin' | 'scholar' | 'pilgrim';
  isPremium: boolean;
  joinedAt: string;
  progress: {
    streak: number;
    level: number;
    totalMinutesRead: number;
    completedBooks: string[];
    xp: number;
    badges: string[];
  };
  stats: {
    versesSaved: number;
    studiesPerformed: number;
    daysActive: number;
  };
}
