
import React, { useState, useEffect } from 'react';
import ReactDOM from 'react-dom/client';
import App from './App';
import { Logo } from './constants';

const Root = () => {
  const [loading, setLoading] = useState(true);
  const [deferredPrompt, setDeferredPrompt] = useState<any>(null);

  useEffect(() => {
    // Timer do Splash Screen
    const timer = setTimeout(() => setLoading(false), 2200);
    
    // Captura o evento de instalação PWA
    const handleBeforeInstall = (e: any) => {
      e.preventDefault();
      setDeferredPrompt(e);
    };

    window.addEventListener('beforeinstallprompt', handleBeforeInstall);
    
    // Registro Estável do Service Worker
    if ('serviceWorker' in navigator) {
      navigator.serviceWorker.register('./sw.js')
        .then(() => console.log("Cathedra Sync: Nexus Ativado"))
        .catch(err => console.debug("SW Indisponível em modo preview"));
    }

    return () => {
      clearTimeout(timer);
      window.removeEventListener('beforeinstallprompt', handleBeforeInstall);
    };
  }, []);

  const handleInstallClick = async () => {
    if (!deferredPrompt) return;
    deferredPrompt.prompt();
    const { outcome } = await deferredPrompt.userChoice;
    if (outcome === 'accepted') setDeferredPrompt(null);
  };

  if (loading) {
    return (
      <div className="fixed inset-0 bg-[#0c0a09] flex flex-col items-center justify-center p-8 z-[2000] animate-in fade-in duration-1000">
        <div className="relative mb-12">
          <Logo className="w-24 h-24 animate-pulse shadow-sacred" />
          <div className="absolute inset-0 bg-gold/10 blur-[60px] rounded-full animate-ping" />
        </div>
        <div className="max-w-md text-center space-y-4">
          <p className="text-xl md:text-2xl font-serif italic text-stone-300 leading-relaxed">"Não se opõe a verdade à verdade."</p>
          <p className="text-[10px] font-black uppercase tracking-[0.4em] text-gold">Cathedra Digital</p>
        </div>
        <div className="absolute bottom-20 w-48 h-1 bg-stone-900 rounded-full overflow-hidden">
          <div className="h-full bg-gold animate-loading-bar" />
        </div>
      </div>
    );
  }

  return (
    <React.StrictMode>
      <App installPrompt={deferredPrompt} onInstall={handleInstallClick} />
    </React.StrictMode>
  );
};

const rootElement = document.getElementById('root');
if (rootElement) {
  ReactDOM.createRoot(rootElement).render(<Root />);
}
