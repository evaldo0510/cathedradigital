
import { bibleData } from '../data/bible.ts';
import { catechismData } from '../data/catechism.ts';
import { documentsData } from '../data/documents.ts';

export interface LocalSearchResult {
  type: 'Bíblia' | 'Catecismo' | 'Documento';
  title: string;
  snippet: string;
  payload: any;
}

export const searchLocal = (query: string): LocalSearchResult[] => {
  const q = query.toLowerCase().trim();
  if (q.length < 3) return [];

  const results: LocalSearchResult[] = [];

  // 1. Busca na Bíblia
  Object.entries(bibleData).forEach(([book, chapters]) => {
    Object.entries(chapters as any).forEach(([chapter, verses]) => {
      Object.entries(verses as any).forEach(([verse, text]) => {
        const verseText = text as string;
        if (verseText.toLowerCase().includes(q)) {
          results.push({
            type: 'Bíblia',
            title: `${book} ${chapter}:${verse}`,
            snippet: verseText,
            payload: { book, chapter: parseInt(chapter), verse: parseInt(verse) }
          });
        }
      });
    });
  });

  // 2. Busca no Catecismo
  catechismData.forEach((section: any) => {
    section.paragraphs.forEach((p: any) => {
      if (p.text.toLowerCase().includes(q) || p.number.toString() === q) {
        results.push({
          type: 'Catecismo',
          title: `CIC §${p.number}`,
          snippet: p.text,
          payload: { number: p.number }
        });
      }
    });
  });

  // 3. Busca nos Documentos
  documentsData.forEach((doc: any) => {
    doc.paragraphs.forEach((p: string, idx: number) => {
      if (p.toLowerCase().includes(q)) {
        results.push({
          type: 'Documento',
          title: `${doc.name} (Par. ${idx + 1})`,
          snippet: p,
          payload: { name: doc.name, index: idx + 1 }
        });
      }
    });
  });

  // Limitar resultados para performance e relevância (prioriza matches exatos de número)
  return results.sort((a, b) => {
     const aExact = a.title.toLowerCase().includes(q) ? 1 : 0;
     const bExact = b.title.toLowerCase().includes(q) ? 1 : 0;
     return bExact - aExact;
  }).slice(0, 15);
};
