
import { offlineStorage } from './offlineStorage';
import { CATHOLIC_BIBLE_BOOKS } from './bibleLocal';
import { fetchBibleChapter, universalSearch } from './gemini';
import { searchSacredVaultFromCloud } from './supabase';
import { Verse, UniversalSearchResult } from '../types';

const GITHUB_BIBLE_RAW = 'https://raw.githubusercontent.com/evaldo0510/cathedra-data/main/biblia';

export const bibleService = {
  async getBooks() {
    return CATHOLIC_BIBLE_BOOKS;
  },

  normalizeBookName(name: string): string {
    return name.toLowerCase()
      .normalize("NFD")
      .replace(/[\u0300-\u036f]/g, "")
      .replace(/\s+/g, '-')
      .replace('1-', '1')
      .replace('2-', '2');
  },

  async getVerses(bookName: string, chapter: number): Promise<Verse[]> {
    try {
      let cachedData = await offlineStorage.getBibleVerses(bookName, chapter);
      if (cachedData && cachedData.length > 0) return cachedData;
    } catch (e) { console.warn("Storage local inacessível."); }

    try {
      const fileName = this.normalizeBookName(bookName);
      const response = await fetch(`${GITHUB_BIBLE_RAW}/${fileName}.json`, { cache: 'force-cache' });
      if (response.ok) {
        const bookData = await response.json();
        const chapterData = bookData.capitulos[chapter - 1];
        if (chapterData?.versiculos) {
          const mapped: Verse[] = chapterData.versiculos.map((v: any) => ({
            book: bookName, chapter: chapter, verse: v.n, text: v.t
          }));
          await offlineStorage.saveBibleVerses(bookName, chapter, mapped);
          return mapped;
        }
      }
    } catch (e) { console.warn(`Fonte nativa falhou para ${bookName}.`); }
    
    const aiData = await fetchBibleChapter(bookName, chapter);
    if (aiData && aiData.length > 0) await offlineStorage.saveBibleVerses(bookName, chapter, aiData);
    return aiData || [];
  },

  async searchContent(query: string, lang: string = 'pt'): Promise<UniversalSearchResult[]> {
    if (query.length < 3) return [];
    
    // Tenta primeiro via Supabase (SQL Search)
    try {
      const cloudResults = await searchSacredVaultFromCloud(query);
      if (cloudResults && cloudResults.length > 0) {
        return cloudResults
          .filter((r: any) => r.source_type.toLowerCase() === 'bíblia')
          .map((r: any) => ({
            id: r.ref_id,
            type: 'Bíblia',
            title: r.title,
            snippet: r.snippet,
            source: { name: 'Vulgata/Almeida', code: 'PRO', reliability: 'High' },
            relevance: r.relevance
          }));
      }
    } catch (e) { console.warn("SQL Search fail, using AI fallback."); }

    // Fallback para busca via Gemini (IA Semantic Search)
    const aiSearch = await universalSearch(query, lang as any);
    return aiSearch.filter(r => r.type.toLowerCase() === 'bíblia');
  }
};
