
import { GoogleGenAI, Modality, Type } from "@google/genai";
import { StudyResult, Verse, Saint, ThomisticArticle, Language, Dogma, LiturgyInfo, Gospel, QuizQuestion, UniversalSearchResult, DailyLiturgyContent, CatechismParagraph } from "../types";
import { offlineStorage } from "./offlineStorage";

const getAI = () => new GoogleGenAI({ apiKey: process.env.API_KEY });

const safeJsonParse = (text: string | undefined, fallback: any) => {
  if (!text) return fallback;
  try {
    const clean = text.replace(/```json/g, "").replace(/```/g, "").trim();
    return JSON.parse(clean) || fallback;
  } catch (e) {
    console.error("Theological Parser Error:", e);
    return fallback;
  }
};

/**
 * MOTOR DE ÁUDIO BÍBLICO (TTS)
 */
export const generateBibleAudio = async (text: string): Promise<string> => {
  const ai = getAI();
  const response = await ai.models.generateContent({
    model: "gemini-2.5-flash-preview-tts",
    contents: [{ parts: [{ text: `Leia solenemente com o tom de um clérigo experiente: ${text}` }] }],
    config: {
      responseModalities: [Modality.AUDIO],
      speechConfig: {
        voiceConfig: {
          prebuiltVoiceConfig: { voiceName: 'Kore' }, 
        },
      },
    },
  });

  const base64Audio = response.candidates?.[0]?.content?.parts?.[0]?.inlineData?.data;
  return base64Audio ? `data:audio/pcm;base64,${base64Audio}` : "";
};

export const fetchBibleChapter = async (book: string, chapter: number): Promise<Verse[]> => {
  // O cache da bíblia é gerenciado primariamente pelo bibleService.ts
  const ai = getAI();
  const response = await ai.models.generateContent({
    model: 'gemini-3-flash-preview',
    contents: `Retorne o texto INTEGRAL de ${book}, capítulo ${chapter}. JSON: [{"book": "${book}", "chapter": ${chapter}, "verse": number, "text": "string"}]`,
    config: { responseMimeType: "application/json" }
  });
  return safeJsonParse(response.text, []);
};

export const fetchCatechismRange = async (start: number, end: number): Promise<CatechismParagraph[]> => {
  const cacheKey = `cic_range_${start}_${end}`;
  const cached = await offlineStorage.getContent(cacheKey);
  if (cached) return cached;

  const ai = getAI();
  const response = await ai.models.generateContent({
    model: 'gemini-3-flash-preview',
    contents: `CIC parágrafos ${start} a ${end}. JSON: [{"number": number, "content": "string", "context": "Doutrina"}]`,
    config: { responseMimeType: "application/json" }
  });
  const data = safeJsonParse(response.text, []);
  if (data.length > 0) await offlineStorage.saveContent(cacheKey, 'catechism', `CIC ${start}-${end}`, data);
  return data;
};

export const getDogmas = async (query: string): Promise<Dogma[]> => {
  const cacheKey = `dogmas_${query.toLowerCase().replace(/\s+/g, '_')}`;
  const cached = await offlineStorage.getContent(cacheKey);
  if (cached) return cached;

  const ai = getAI();
  const response = await ai.models.generateContent({
    model: 'gemini-3-pro-preview',
    contents: `Dogmas sobre: "${query}". JSON: Array<{ title: string, definition: string, council: string, year: string, tags: string[], period: string }>`,
    config: { responseMimeType: "application/json" }
  });
  const data = safeJsonParse(response.text, []);
  if (data.length > 0) await offlineStorage.saveContent(cacheKey, 'magisterium', `Dogmas: ${query}`, data);
  return data;
};

export const fetchLitanies = async (t: string, l: Language): Promise<any> => {
  const cacheKey = `litany_${t.toLowerCase().replace(/\s+/g, '_')}`;
  const cached = await offlineStorage.getContent(cacheKey);
  if (cached) return cached;

  const ai = getAI();
  const response = await ai.models.generateContent({
    model: 'gemini-3-flash-preview',
    contents: `Ladainha: ${t}. JSON: { "title": "string", "items": [{"call": "string", "response": "string"}] }`,
    config: { responseMimeType: "application/json" }
  });
  const data = safeJsonParse(response.text, { title: t, items: [] });
  if (data.items.length > 0) await offlineStorage.saveContent(cacheKey, 'magisterium', t, data);
  return data;
};

export const searchSaint = async (name: string): Promise<Partial<Saint>> => {
  const cacheKey = `saint_detail_${name.toLowerCase().replace(/\s+/g, '_')}`;
  const cached = await offlineStorage.getContent(cacheKey);
  if (cached) return cached;

  const ai = getAI();
  const response = await ai.models.generateContent({
    model: 'gemini-3-flash-preview',
    contents: `Santo: ${name}. JSON: { "biography": "string", "quote": "string" }`,
    config: { responseMimeType: "application/json" }
  });
  const data = safeJsonParse(response.text, {});
  if (data.biography) await offlineStorage.saveContent(cacheKey, 'saint', name, data);
  return data;
};

export const fetchBreviaryHour = async (h: string, l: Language): Promise<any> => {
  // Cache por hora do dia e data para evitar re-geração no mesmo dia
  const dateKey = new Date().toISOString().split('T')[0];
  const cacheKey = `breviary_${h}_${dateKey}`;
  const cached = await offlineStorage.getContent(cacheKey);
  if (cached) return cached;

  const ai = getAI();
  const response = await ai.models.generateContent({
    model: 'gemini-3-pro-preview',
    contents: `Breviário: ${h} para o dia ${dateKey}. JSON: { "hourName": "string", "invitatory": "string", "hymn": "string", "psalms": [{"ref": "string", "text": "string"}], "prayer": "string" }`,
    config: { responseMimeType: "application/json" }
  });
  const data = safeJsonParse(response.text, {});
  if (data.hourName) await offlineStorage.saveContent(cacheKey, 'magisterium', `Breviário ${h}`, data);
  return data;
};

export const getMagisteriumDeepDive = async (title: string, lang: Language): Promise<any> => {
  const cacheKey = `magisterium_dive_${title.toLowerCase().replace(/\s+/g, '_')}`;
  const cached = await offlineStorage.getContent(cacheKey);
  if (cached) return cached;

  const ai = getAI();
  const response = await ai.models.generateContent({
    model: 'gemini-3-pro-preview',
    contents: `Documento: "${title}". JSON: { "historicalContext": "string", "corePoints": [], "modernApplication": "string", "relatedCatechism": [] }`,
    config: { responseMimeType: "application/json" }
  });
  const data = safeJsonParse(response.text, {});
  if (data.historicalContext) await offlineStorage.saveContent(cacheKey, 'magisterium', `Deep Dive: ${title}`, data);
  return data;
};

export const getThomisticSynthesis = async (query: string): Promise<any> => {
  const cacheKey = `thomistic_${query.toLowerCase().replace(/\s+/g, '_')}`;
  const cached = await offlineStorage.getContent(cacheKey);
  if (cached) return cached;

  const ai = getAI();
  const response = await ai.models.generateContent({
    model: 'gemini-3-pro-preview',
    contents: `Investigação escolástica: "${query}". JSON: { "title": "string", "objections": ["string"], "sedContra": "string", "respondeo": "string", "replies": ["string"] }`,
    config: { responseMimeType: "application/json" }
  });
  const data = safeJsonParse(response.text, { title: query, objections: [], sedContra: "", respondeo: "", replies: [] });
  if (data.respondeo) await offlineStorage.saveContent(cacheKey, 'magisterium', `Tomismo: ${query}`, data);
  return data;
};

// Funções dinâmicas (Sem Cache)
export const universalSearch = async (query: string, lang: Language): Promise<UniversalSearchResult[]> => {
  const ai = getAI();
  const response = await ai.models.generateContent({
    model: 'gemini-3-flash-preview',
    contents: `Busca universal católica: "${query}". JSON: Array<{ id: string, type: string, title: string, snippet: string, source: { name: string, code: string }, relevance: number }>`,
    config: { responseMimeType: "application/json" }
  });
  return safeJsonParse(response.text, []);
};

export const getIntelligentStudy = async (topic: string, lang: Language = 'pt'): Promise<StudyResult> => {
  const ai = getAI();
  const response = await ai.models.generateContent({
    model: 'gemini-3-pro-preview',
    contents: `Investigação profunda: "${topic}". JSON: { "topic": "string", "summary": "string", "bibleVerses": [], "catechismParagraphs": [], "magisteriumDocs": [], "saintsQuotes": [] }`,
    config: { responseMimeType: "application/json" }
  });
  return safeJsonParse(response.text, { topic, summary: "Erro.", bibleVerses: [], catechismParagraphs: [] });
};

export const getDailyGospel = async (): Promise<Gospel> => {
  const ai = getAI();
  const response = await ai.models.generateContent({
    model: 'gemini-3-flash-preview',
    contents: `Evangelho de hoje. JSON: { "reference": "string", "text": "string" }`,
    config: { responseMimeType: "application/json" }
  });
  return safeJsonParse(response.text, { reference: "", text: "" });
};

export async function* getTheologicalDialogueStream(message: string) {
  const ai = getAI();
  const response = await ai.models.generateContentStream({
    model: 'gemini-3-flash-preview',
    contents: message,
    config: {
      systemInstruction: "Você é o 'Doctor Angelicus' (Santo Tomás de Aquino). Responda com rigor escolástico e caridade.",
    },
  });
  for await (const chunk of response) {
    if (chunk.text) yield chunk.text;
  }
}

// FIX: Added missing exported member 'getCatenaAureaCommentary'
/**
 * CONSULTA CATENA AUREA
 */
export const getCatenaAureaCommentary = async (verse: Verse): Promise<any> => {
  const ai = getAI();
  const response = await ai.models.generateContent({
    model: 'gemini-3-pro-preview',
    contents: `Catena Aurea para ${verse.book} ${verse.chapter}:${verse.verse}. Retorne um JSON com a compilação patrística. JSON: { "content": "string", "fathers": ["string"], "sources": [{"title": "string", "uri": "string"}] }`,
    config: { responseMimeType: "application/json" }
  });
  return safeJsonParse(response.text, { content: "", fathers: [], sources: [] });
};

// FIX: Added missing exported member 'fetchMonthlyCalendar'
/**
 * CALENDÁRIO MENSAL
 */
export const fetchMonthlyCalendar = async (month: number, year: number, lang: Language): Promise<LiturgyInfo[]> => {
  const ai = getAI();
  const response = await ai.models.generateContent({
    model: 'gemini-3-flash-preview',
    contents: `Gere o calendário litúrgico católico para o mês ${month} do ano ${year} no idioma ${lang}. Retorne um array de objetos LiturgyInfo em JSON. Formato: Array<{ "color": "green"|"purple"|"white"|"red"|"rose"|"black", "season": "string", "rank": "string", "date": "YYYY-MM-DD", "dayName": "string", "cycle": "string", "week": "string" }>`,
    config: { responseMimeType: "application/json" }
  });
  return safeJsonParse(response.text, []);
};

// FIX: Added missing exported member 'getLectioPoints'
/**
 * PONTOS DE MEDITAÇÃO LECTIO
 */
export const getLectioPoints = async (text: string): Promise<string[]> => {
  const ai = getAI();
  const response = await ai.models.generateContent({
    model: 'gemini-3-flash-preview',
    contents: `Dê 3 a 5 pontos curtos de meditação espiritual para o texto: "${text}". Retorne apenas um array JSON de strings.`,
    config: { responseMimeType: "application/json" }
  });
  return safeJsonParse(response.text, []);
};

// FIX: Added missing exported member 'getDailyBundle'
/**
 * BUNDLE DIÁRIO (NOTIFICAÇÕES)
 */
export const getDailyBundle = async (lang: Language): Promise<{ saint: Saint, gospel: Gospel }> => {
  const ai = getAI();
  const response = await ai.models.generateContent({
    model: 'gemini-3-flash-preview',
    contents: `Forneça o Santo do dia e o Evangelho de hoje. Idioma: ${lang}. JSON: { "saint": { "name": "string", "feastDay": "string", "patronage": "string", "biography": "string", "image": "string" }, "gospel": { "reference": "string", "text": "string" } }`,
    config: { responseMimeType: "application/json" }
  });
  return safeJsonParse(response.text, { 
    saint: { name: "", feastDay: "", patronage: "", biography: "", image: "" }, 
    gospel: { reference: "", text: "" } 
  });
};

// FIX: Added missing exported member 'fetchThomisticArticle'
/**
 * ARTIGO TOMISTA
 */
export const fetchThomisticArticle = async (work: string, ref: string, lang: Language): Promise<ThomisticArticle> => {
  const ai = getAI();
  const response = await ai.models.generateContent({
    model: 'gemini-3-pro-preview',
    contents: `Extraia ou gere o artigo de Santo Tomás de Aquino: "${work}", referência "${ref}". Idioma: ${lang}. JSON: { "reference": "${ref}", "articleTitle": "string", "objections": [{"id": number, "text": "string"}], "respondeo": "string" }`,
    config: { responseMimeType: "application/json" }
  });
  return safeJsonParse(response.text, { reference: ref, articleTitle: "", objections: [], respondeo: "" });
};

// FIX: Added missing exported member 'getMoralDiscernment'
/**
 * DISCERNIMENTO MORAL
 */
export const getMoralDiscernment = async (input: string, lang: Language): Promise<any> => {
  const ai = getAI();
  const response = await ai.models.generateContent({
    model: 'gemini-3-pro-preview',
    contents: `Analise moralmente sob a ótica católica: "${input}". Idioma: ${lang}. JSON: { "gravity": "mortal"|"venial", "explanation": "string", "cicRef": "string" }`,
    config: { responseMimeType: "application/json" }
  });
  return safeJsonParse(response.text, { gravity: 'venial', explanation: "Erro na análise.", cicRef: "" });
};

// FIX: Added missing exported member 'fetchQuizQuestions'
/**
 * PERGUNTAS DE QUIZ
 */
export const fetchQuizQuestions = async (category: string, difficulty: string, lang: Language): Promise<QuizQuestion[]> => {
  const ai = getAI();
  const response = await ai.models.generateContent({
    model: 'gemini-3-flash-preview',
    contents: `Gere 5 perguntas de quiz católico sobre "${category}" nível "${difficulty}". Idioma: ${lang}. JSON: Array<{ "id": "string", "question": "string", "options": ["string"], "correctAnswer": number, "explanation": "string", "category": "${category}", "difficulty": "${difficulty}" }>`,
    config: { responseMimeType: "application/json" }
  });
  return safeJsonParse(response.text, []);
};
