import { LearningTrack } from "../types";

export const NATIVE_TRACKS: LearningTrack[] = [
  {
    id: "fundamentos-fe",
    title: "Fundamentos da Fé",
    description: "A porta de entrada para organizar sua fé. Entenda a estrutura da Igreja, o Credo e as fontes da revelação.",
    level: "Iniciante",
    icon: "🔰",
    image: "https://images.unsplash.com/photo-1548610762-656391d1ad4d?q=80&w=1200",
    modules: [
      {
        id: "intro-igreja",
        title: "O que é a Igreja?",
        content: [
          { type: "cic", ref: "741", label: "A missão de ensinar" },
          { type: "cic", ref: "751", label: "O termo 'Igreja'" }
        ]
      },
      {
        id: "o-credo",
        title: "O Credo Comentado",
        content: [
          { type: "cic", ref: "185", label: "Os símbolos da fé" },
          { type: "cic", ref: "198", label: "Creio em Deus Pai" }
        ]
      }
    ]
  },
  {
    id: "biblia-igreja",
    title: "Bíblia na Vida da Igreja",
    description: "Como ler as Escrituras com os olhos da Tradição. Do Antigo ao Novo Testamento em harmonia.",
    level: "Iniciante",
    icon: "📘",
    image: "https://images.unsplash.com/photo-1504052434569-70ad5836ab65?q=80&w=1200",
    modules: [
      {
        id: "hermeneutica",
        title: "Como ler catolicamente",
        content: [
          { type: "documento", ref: "Dei Verbum", label: "A Palavra de Deus" },
          { type: "cic", ref: "109", label: "Os sentidos da Escritura" }
        ]
      },
      {
        id: "biblia-liturgia",
        title: "Bíblia e Liturgia",
        content: [
          { type: "biblia", ref: "Lucas 24:13-35", label: "Os discípulos de Emaús" },
          { type: "cic", ref: "1154", label: "A mesa da Palavra" }
        ]
      }
    ]
  },
  {
    id: "catecismo-essencial",
    title: "Catecismo (Estrutural)",
    description: "Um percurso sólido pelas quatro partes do CIC: Fé, Culto, Vida e Oração.",
    level: "Intermediário",
    icon: "📜",
    image: "https://images.unsplash.com/photo-1519791883288-dc8bd696e667?q=80&w=1200",
    modules: [
      {
        id: "cic-parte-1",
        title: "Profissão de Fé",
        content: [
          { type: "cic", ref: "26", label: "Creio - Cremos" }
        ]
      },
      {
        id: "cic-parte-2",
        title: "Celebração do Mistério",
        content: [
          { type: "cic", ref: "1066", label: "A Liturgia da Igreja" }
        ]
      }
    ]
  },
  {
    id: "magisterio-vivo",
    title: "Documentos da Igreja",
    description: "O Magistério vivo falando com a Igreja hoje. Concílios, Encíclicas e Exortações.",
    level: "Avançado",
    icon: "⛪",
    image: "https://images.unsplash.com/photo-1438232992991-995b7058bbb3?q=80&w=1200",
    modules: [
      {
        id: "vaticano-ii",
        title: "O Concílio Vaticano II",
        content: [
          { type: "documento", ref: "Lumen Gentium", label: "A Igreja é Luz" }
        ]
      }
    ]
  },
  {
    id: "maturidade-crista",
    title: "Maturidade Cristã",
    description: "Fé aplicada à vida: moral, consciência, discernimento e vida espiritual profunda.",
    level: "Avançado",
    icon: "🧭",
    image: "https://images.unsplash.com/photo-1507413245164-6160d8298b31?q=80&w=1200",
    modules: [
      {
        id: "consciencia-moral",
        title: "Consciência e Moral",
        content: [
          { type: "cic", ref: "1776", label: "O santuário da consciência" }
        ]
      }
    ]
  }
];

export const getTrackById = (id: string) => NATIVE_TRACKS.find(t => t.id === id);