
import React, { useState, useEffect, useRef } from 'react';
import { Icons } from '../constants';
import { catechismData } from '../data/catechism.ts';
import CrossLinkText from './CrossLinkText';

interface CatechismModalProps {
  isOpen: boolean;
  onClose: () => void;
  onBibleJump: (book: string, chapter: number, verse: number) => void;
  targetPara?: number | null;
}

const CatechismModal: React.FC<CatechismModalProps> = ({ isOpen, onClose, onBibleJump, targetPara }) => {
  const paraRefs = useRef<Record<number, HTMLDivElement | null>>({});

  useEffect(() => {
    if (isOpen && targetPara) {
      setTimeout(() => {
        paraRefs.current[targetPara]?.scrollIntoView({ behavior: 'smooth', block: 'start' });
      }, 500);
    }
  }, [isOpen, targetPara]);

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-[1000] flex items-center justify-center p-4">
      <div className="absolute inset-0 bg-stone-950/80 backdrop-blur-md" onClick={onClose} />
      <div className="relative w-full max-w-4xl bg-[#fdfcf8] dark:bg-stone-900 rounded-[3rem] shadow-4xl border border-gold/20 flex flex-col max-h-[85vh] overflow-hidden animate-sacred">
        <header className="p-6 border-b border-stone-100 dark:border-stone-800 flex items-center justify-between">
          <div className="flex items-center gap-4">
            <Icons.Cross className="w-6 h-6 text-sacred" />
            <h2 className="text-xl font-serif font-bold text-stone-900 dark:text-gold uppercase tracking-widest">Codex Fidei</h2>
          </div>
          <button onClick={onClose} className="p-2 hover:bg-stone-100 dark:hover:bg-stone-800 rounded-full">
            <Icons.Cross className="w-5 h-5 rotate-45" />
          </button>
        </header>

        <div className="flex-1 overflow-y-auto p-8 custom-scrollbar space-y-12">
          {catechismData.map((part, pIdx) => (
            <div key={pIdx} className="space-y-8">
              <h3 className="text-3xl font-serif font-bold text-sacred border-l-4 border-sacred pl-6">{part.part}</h3>
              <div className="space-y-6">
                {part.paragraphs.map((p: any) => (
                  <div 
                    key={p.number} 
                    ref={el => paraRefs.current[p.number] = el}
                    className={`p-6 rounded-3xl border transition-all duration-1000 ${targetPara === p.number ? 'bg-gold/10 border-gold shadow-lg' : 'bg-white dark:bg-stone-800 border-stone-100'}`}
                  >
                    <div className="flex items-center gap-4 mb-4">
                      <div className="w-10 h-10 rounded-xl bg-stone-900 text-gold flex items-center justify-center font-black text-xs shadow-md">§ {p.number}</div>
                      <span className="text-[10px] font-black uppercase text-stone-400 tracking-widest">{p.context}</span>
                    </div>
                    <CrossLinkText 
                      text={p.text}
                      onBibleJump={onBibleJump}
                      onCatechismJump={(num) => paraRefs.current[num]?.scrollIntoView({ behavior: 'smooth' })}
                      className="font-serif text-xl md:text-2xl leading-relaxed text-justify block text-stone-800 dark:text-stone-200"
                    />
                  </div>
                ))}
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default CatechismModal;
