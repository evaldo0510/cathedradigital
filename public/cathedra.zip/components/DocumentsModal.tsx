
import React, { useState, useEffect } from 'react';
import { Icons } from '../constants';
import { documentsData } from '../data/documents.ts';
import CrossLinkText from './CrossLinkText';

interface DocumentsModalProps {
  isOpen: boolean;
  onClose: () => void;
  onBibleJump: (book: string, chapter: number, verse: number) => void;
  onCatechismJump: (para: number) => void;
}

const DocumentsModal: React.FC<DocumentsModalProps> = ({ isOpen, onClose, onBibleJump, onCatechismJump }) => {
  const [selectedDoc, setSelectedDoc] = useState<any | null>(null);

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-[1000] flex items-center justify-center p-4">
      <div className="absolute inset-0 bg-stone-950/80 backdrop-blur-md" onClick={onClose} />
      <div className="relative w-full max-w-4xl bg-[#fdfcf8] dark:bg-stone-900 rounded-[3rem] shadow-4xl border border-gold/20 flex flex-col max-h-[85vh] overflow-hidden animate-sacred">
        <header className="p-6 border-b border-stone-100 dark:border-stone-800 flex items-center justify-between">
          <div className="flex items-center gap-4">
            <Icons.Globe className="w-6 h-6 text-sacred" />
            <h2 className="text-xl font-serif font-bold text-stone-900 dark:text-gold uppercase tracking-widest">Magisterium</h2>
          </div>
          <button onClick={onClose} className="p-2 hover:bg-stone-100 dark:hover:bg-stone-800 rounded-full">
            <Icons.Cross className="w-5 h-5 rotate-45" />
          </button>
        </header>

        <div className="flex-1 overflow-y-auto p-8 custom-scrollbar">
          {!selectedDoc ? (
            <div className="grid gap-4">
              {documentsData.map((doc, idx) => (
                <button 
                  key={idx} 
                  onClick={() => setSelectedDoc(doc)}
                  className="p-8 bg-white dark:bg-stone-800 rounded-[2.5rem] border border-stone-100 hover:border-gold transition-all text-left flex justify-between items-center group"
                >
                  <div>
                    <h3 className="text-2xl font-serif font-bold group-hover:text-sacred transition-colors">{doc.name}</h3>
                    <p className="text-stone-400 text-xs font-black uppercase tracking-widest mt-1">Proclamado em {doc.year}</p>
                  </div>
                  <Icons.ArrowDown className="w-5 h-5 -rotate-90 text-stone-200 group-hover:text-gold" />
                </button>
              ))}
            </div>
          ) : (
            <div className="space-y-10 pb-10">
              <button onClick={() => setSelectedDoc(null)} className="text-gold text-xs font-black uppercase tracking-widest flex items-center gap-2">
                <Icons.ArrowDown className="w-3 h-3 rotate-90" /> Voltar ao Arquivo
              </button>
              <div className="text-center space-y-2">
                <h3 className="text-4xl md:text-6xl font-serif font-bold leading-tight">{selectedDoc.name}</h3>
                <p className="text-gold font-serif italic text-xl">{selectedDoc.year}</p>
              </div>
              <div className="space-y-8 font-serif text-2xl leading-relaxed text-justify text-stone-800 dark:text-stone-200 indent-12">
                {selectedDoc.paragraphs.map((p: string, idx: number) => (
                  <CrossLinkText 
                    key={idx}
                    text={p}
                    onBibleJump={onBibleJump}
                    onCatechismJump={onCatechismJump}
                    className="block mb-6"
                  />
                ))}
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default DocumentsModal;
