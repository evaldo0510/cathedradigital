
import React from 'react';
import { ShieldCheck, ExternalLink, BookOpen, Scroll, Globe, Star, Heart } from 'lucide-react';
import { AppRoute } from '../types';
import { Logo } from '../constants';

interface FooterProps {
  onNavigate: (r: AppRoute) => void;
  onOpenBible: () => void;
  onOpenCatechism: () => void;
  onOpenDocs: () => void;
}

const Footer: React.FC<FooterProps> = ({ onNavigate, onOpenBible, onOpenCatechism, onOpenDocs }) => {
  return (
    <footer className="bg-[#050505] border-t border-white/5 pt-24 pb-12 overflow-hidden relative">
      {/* Elemento Decorativo de Fundo */}
      <div className="absolute top-0 right-0 w-96 h-96 bg-gold/5 blur-[120px] rounded-full -mr-48 -mt-48 pointer-events-none" />
      
      <div className="max-w-7xl mx-auto px-6 md:px-10 relative z-10">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-16 md:gap-20 mb-24">
          
          {/* Brand & Missão */}
          <div className="space-y-8">
            <div 
              onClick={() => onNavigate(AppRoute.DASHBOARD)} 
              className="flex items-center gap-4 cursor-pointer group"
            >
              <Logo className="w-12 h-12 grayscale brightness-200 group-hover:grayscale-0 transition-all duration-700" />
              <div>
                <span className="text-2xl font-serif font-bold tracking-tighter block leading-none text-white uppercase">CATHEDRA.</span>
                <span className="text-[8px] font-bold tracking-[0.3em] text-gold uppercase">Digital Sanctuarium</span>
              </div>
            </div>
            <p className="text-stone-500 text-sm leading-relaxed font-serif italic">
              "A Verdade não se impõe senão pela força da própria verdade." — Dignitatis Humanae.
              Dedicado ao estudo fiel do Depósito da Fé Católica.
            </p>
            <div className="flex gap-3">
              {['Fidelitas', 'Claritas', 'Humilitas'].map(word => (
                <span key={word} className="text-[7px] uppercase tracking-[0.2em] text-stone-600 border border-white/5 px-3 py-1.5 rounded-full">
                  {word}
                </span>
              ))}
            </div>
          </div>

          {/* Navegação Interna */}
          <div>
            <h4 className="text-[10px] font-black uppercase tracking-[0.3em] text-gold mb-10 border-b border-gold/10 pb-4">Santuário</h4>
            <ul className="space-y-4">
              {[
                { label: 'Página Inicial', route: AppRoute.DASHBOARD },
                { label: 'Liturgia Diária', route: AppRoute.DAILY_LITURGY },
                { label: 'Trilhas de Formação', route: AppRoute.TRILHAS },
                { label: 'Vidas dos Santos', route: AppRoute.SAINTS },
                { label: 'Memorial de Estudos', route: AppRoute.FAVORITES }
              ].map(item => (
                <li 
                  key={item.label}
                  onClick={() => onNavigate(item.route)}
                  className="text-stone-400 hover:text-white text-sm font-medium cursor-pointer transition-colors flex items-center gap-2 group"
                >
                  <div className="w-1 h-1 bg-stone-800 rounded-full group-hover:bg-gold transition-colors" />
                  {item.label}
                </li>
              ))}
            </ul>
          </div>

          {/* Ferramentas e Fontes */}
          <div>
            <h4 className="text-[10px] font-black uppercase tracking-[0.3em] text-gold mb-10 border-b border-gold/10 pb-4">Scriptorium</h4>
            <ul className="space-y-4">
              <li onClick={onOpenBible} className="text-stone-400 hover:text-emerald-500 text-sm font-medium cursor-pointer transition-colors flex items-center gap-3 group">
                <BookOpen size={14} className="group-hover:rotate-12 transition-transform" /> Bíblia Sagrada
              </li>
              <li onClick={onOpenCatechism} className="text-stone-400 hover:text-sacred text-sm font-medium cursor-pointer transition-colors flex items-center gap-3 group">
                <Scroll size={14} className="group-hover:rotate-12 transition-transform" /> Catecismo (CIC)
              </li>
              <li onClick={onOpenDocs} className="text-stone-400 hover:text-blue-500 text-sm font-medium cursor-pointer transition-colors flex items-center gap-3 group">
                <ShieldCheck size={14} className="group-hover:rotate-12 transition-transform" /> Magistério Vivo
              </li>
              <li onClick={() => onNavigate(AppRoute.AQUINAS_OPERA)} className="text-stone-400 hover:text-gold text-sm font-medium cursor-pointer transition-colors flex items-center gap-3 group">
                <Heart size={14} className="group-hover:rotate-12 transition-transform" /> Opera Omnia
              </li>
            </ul>
          </div>

          {/* Fontes Externas */}
          <div>
            <h4 className="text-[10px] font-black uppercase tracking-[0.3em] text-gold mb-10 border-b border-gold/10 pb-4">Conexão Universal</h4>
            <ul className="space-y-4">
              {[
                { label: 'Vaticano (vatican.va)', url: 'https://www.vatican.va' },
                { label: 'Santa Sé Archive', url: 'https://www.vatican.va/archive/index_po.htm' },
                { label: 'CNBB Oficial', url: 'https://www.cnbb.org.br' },
                { label: 'Vatican News', url: 'https://www.vaticannews.va' }
              ].map(item => (
                <li key={item.label}>
                  <a 
                    href={item.url} 
                    target="_blank" 
                    rel="noreferrer" 
                    className="text-stone-500 hover:text-white text-xs flex items-center gap-2 transition-colors"
                  >
                    <ExternalLink size={12}/> {item.label}
                  </a>
                </li>
              ))}
            </ul>
          </div>
        </div>

        {/* Barra Final */}
        <div className="pt-12 border-t border-white/5 flex flex-col md:flex-row justify-between items-center gap-8">
          <div className="flex items-center gap-6">
            <div className="text-[10px] font-black text-stone-700 tracking-[0.4em] uppercase">
              © CATHEDRA DIGITAL • MMXXIV
            </div>
            <div className="h-4 w-px bg-white/5 hidden md:block" />
            <div className="text-[9px] font-serif italic text-stone-600">
              Ad Maiorem Dei Gloriam
            </div>
          </div>
          
          <div className="flex gap-8 opacity-20 hover:opacity-50 transition-opacity">
            <ShieldCheck size={18} className="text-white" />
            <Star size={18} className="text-gold" />
            <Heart size={18} className="text-sacred" />
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
