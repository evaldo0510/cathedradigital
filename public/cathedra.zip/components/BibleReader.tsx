
import React, { useState, useMemo, useEffect, useRef } from 'react';
import { Icons } from '../constants';
import { Verse } from '../types';
import ActionButtons from './ActionButtons';
import ReadingModeToggle from './ReadingModeToggle';
import ReflectionBox from './ReflectionBox';
import CrossLinkText from './CrossLinkText';

interface BibleReaderProps {
  book: string;
  chapter: number;
  verses: Verse[];
  initialVerse?: number | null;
  onBibleJump: (book: string, chapter: number, verse: number) => void;
  onCatechismJump: (para: number) => void;
}

const BibleReader: React.FC<BibleReaderProps> = ({ book, chapter, verses, initialVerse, onBibleJump, onCatechismJump }) => {
  const [fontSize, setFontSize] = useState(1.25);
  const [mode, setMode] = useState<'study' | 'prayer'>('study');
  const [activeVerse, setActiveVerse] = useState<number | null>(null);
  const verseRefs = useRef<Record<number, HTMLDivElement | null>>({});

  useEffect(() => {
    if (initialVerse) {
      setActiveVerse(initialVerse);
      setTimeout(() => {
        verseRefs.current[initialVerse]?.scrollIntoView({ behavior: 'smooth', block: 'center' });
      }, 500);
    }
  }, [initialVerse, chapter, book]);

  const containerClasses = useMemo(() => {
    if (mode === 'prayer') return 'bg-[#fdfcf8] text-[#3e3a32] -mx-4 md:-mx-12 px-8 md:px-24 pt-32 pb-60 shadow-inner';
    return 'max-w-4xl mx-auto px-6 pb-40 pt-10';
  }, [mode]);

  return (
    <div className={`transition-all duration-1000 min-h-screen ${containerClasses}`}>
      
      {/*Reading Controls */}
      <div className="sticky top-24 z-[100] flex justify-center mb-24 pointer-events-none">
        <div className="pointer-events-auto bg-white/95 dark:bg-stone-900/95 backdrop-blur-2xl border border-stone-200 dark:border-stone-800 px-8 py-3.5 rounded-[2.5rem] shadow-premium flex items-center gap-8">
          <div className="flex items-center gap-5 border-r border-stone-200 dark:border-stone-800 pr-8">
            <button onClick={() => setFontSize(f => Math.max(1, f - 0.1))} className="text-stone-400 hover:text-gold transition-colors font-bold text-lg">A-</button>
            <div className="w-px h-4 bg-stone-200 dark:bg-stone-800" />
            <button onClick={() => setFontSize(f => Math.min(2.5, f + 0.1))} className="text-stone-400 hover:text-gold transition-colors font-bold text-2xl">A+</button>
          </div>
          
          <ReadingModeToggle mode={mode} setMode={setMode} />
          
          {mode === 'study' && (
            <div className="ml-2 flex items-center gap-3">
              <Icons.Book className="w-4 h-4 text-gold opacity-50" />
              <span className="text-[10px] font-black uppercase tracking-widest text-stone-400">Modus Scriptorium</span>
            </div>
          )}
        </div>
      </div>
      
      {/*Header */}
      <header className="text-center space-y-6 mb-32">
        <div className="flex items-center justify-center gap-6 mb-4">
           <div className="h-px w-20 bg-gold/30" />
           <span className="text-[11px] font-black uppercase tracking-[0.8em] text-gold">Sacra Scriptura</span>
           <div className="h-px w-20 bg-gold/30" />
        </div>
        <h1 className={`font-serif font-bold tracking-tighter leading-none transition-all duration-1000 ${mode === 'prayer' ? 'text-7xl md:text-[10rem]' : 'text-5xl md:text-8xl text-stone-900 dark:text-white'}`}>
          {book}
        </h1>
        <p className={`font-serif italic transition-all duration-1000 ${mode === 'prayer' ? 'text-4xl opacity-40' : 'text-2xl text-stone-400'}`}>
          Capitulum <span className="text-sacred font-bold">{chapter}</span>
        </p>
      </header>

      {/*The Text Block */}
      <article 
        className={`font-serif transition-all duration-1000 mx-auto leading-[1.85] text-justify selection:bg-gold/30 ${mode === 'prayer' ? 'max-w-3xl space-y-16 italic' : 'max-w-4xl space-y-6'}`}
        style={{ fontSize: `${fontSize}rem` }}
      >
        {verses.map((v) => {
          const isSelected = activeVerse === v.verse;
          return (
            <div 
              key={v.verse}
              ref={el => verseRefs.current[v.verse] = el}
              className={`relative transition-all duration-500 rounded-3xl ${mode === 'study' ? (isSelected ? 'bg-white dark:bg-stone-800 shadow-xl p-8 ring-1 ring-gold/20' : 'p-2 hover:bg-stone-50 dark:hover:bg-stone-900/40') : 'group'}`}
              onClick={() => setActiveVerse(isSelected ? null : v.verse)}
            >
              <div className="flex gap-10">
                <span className={`text-[11px] font-black font-sans opacity-20 mt-3 w-8 shrink-0 text-right ${isSelected ? 'text-gold opacity-100' : ''}`}>
                  {v.verse}
                </span>
                <div className={`text-stone-800 dark:text-stone-200 transition-all duration-700 ${isSelected ? 'opacity-100' : 'opacity-90'}`}>
                  <CrossLinkText 
                    text={v.text} 
                    onBibleJump={onBibleJump} 
                    onCatechismJump={onCatechismJump} 
                  />
                </div>
              </div>
              
              {isSelected && (
                <div className="mt-8 ml-18 animate-in fade-in slide-in-from-top-4">
                  <ActionButtons 
                    itemId={`v_${book}_${chapter}_${v.verse}`} 
                    type="verse" 
                    title={`${book} ${chapter}:${v.verse}`} 
                    content={v.text} 
                    className="bg-stone-50 dark:bg-stone-900/50 p-3 rounded-2xl border border-stone-100 dark:border-stone-700"
                  />
                </div>
              )}
            </div>
          );
        })}
      </article>

      <div className="mt-40 max-w-3xl mx-auto">
        <ReflectionBox itemId={`bible_${book}_${chapter}`} title={`Reflexão: ${book} ${chapter}`} />
      </div>

      <footer className="mt-60 pt-20 border-t border-stone-200 dark:border-stone-800 text-center opacity-20">
        <Icons.Cross className="w-12 h-12 mx-auto mb-6 text-stone-400" />
        <p className="text-[12px] font-black uppercase tracking-[1em]">Sempra Fidelis • Hodie</p>
      </footer>
    </div>
  );
};

export default BibleReader;
