
import React from 'react';

interface CrossLinkTextProps {
  text: string;
  onBibleJump: (book: string, chapter: number, verse: number) => void;
  onCatechismJump: (para: number) => void;
  className?: string;
}

const CrossLinkText: React.FC<CrossLinkTextProps> = ({ text, onBibleJump, onCatechismJump, className = "" }) => {
  if (!text) return null;

  // Regex para Bíblia: Suporta "Livro Ch:Ver", "São João 3:16", "1 Corintios 13:1"
  const bibleRegex = /((?:\d\s)?[A-ZÀ-Ÿ][a-zà-ÿ]+(?:(?:\s[A-ZÀ-Ÿ][a-zà-ÿ]+)+)?)\s+(\d+)[:|,]\s?(\d+)/g;
  // Regex para Catecismo: "CIC numero", "§ numero"
  const cicRegex = /(?:CIC|§)\s?(\d+)/g;

  const matches: { start: number, end: number, type: 'bible' | 'cic', data: any, original: string }[] = [];

  let bMatch;
  while ((bMatch = bibleRegex.exec(text)) !== null) {
    matches.push({
      start: bMatch.index,
      end: bMatch.index + bMatch[0].length,
      type: 'bible',
      data: { book: bMatch[1].trim(), chapter: parseInt(bMatch[2]), verse: parseInt(bMatch[3]) },
      original: bMatch[0]
    });
  }

  let cMatch;
  while ((cMatch = cicRegex.exec(text)) !== null) {
    matches.push({
      start: cMatch.index,
      end: cMatch.index + cMatch[0].length,
      type: 'cic',
      data: { para: parseInt(cMatch[1]) },
      original: cMatch[0]
    });
  }

  matches.sort((a, b) => a.start - b.start);
  const filteredMatches = matches.filter((m, i) => i === 0 || m.start >= matches[i-1].end);

  let currentPos = 0;
  const nodes = [];

  filteredMatches.forEach((m, i) => {
    if (m.start > currentPos) {
      nodes.push(text.substring(currentPos, m.start));
    }

    if (m.type === 'bible') {
      nodes.push(
        <button
          key={`b-${i}`}
          onClick={(e) => { e.stopPropagation(); onBibleJump(m.data.book, m.data.chapter, m.data.verse); }}
          className="text-sacred dark:text-gold font-bold underline decoration-dotted decoration-sacred/40 hover:bg-gold/10 px-1 rounded transition-colors inline-block"
        >
          {m.original}
        </button>
      );
    } else {
      nodes.push(
        <button
          key={`c-${i}`}
          onClick={(e) => { e.stopPropagation(); onCatechismJump(m.data.para); }}
          className="text-amber-700 dark:text-amber-400 font-bold underline decoration-dotted decoration-amber-500/40 hover:bg-amber-500/10 px-1 rounded transition-colors inline-block"
        >
          {m.original}
        </button>
      );
    }
    currentPos = m.end;
  });

  if (currentPos < text.length) {
    nodes.push(text.substring(currentPos));
  }

  return <span className={className}>{nodes.length > 0 ? nodes : text}</span>;
};

export default CrossLinkText;
