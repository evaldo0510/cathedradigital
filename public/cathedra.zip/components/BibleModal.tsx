
import React, { useState, useEffect, useRef } from 'react';
import { Icons } from '../constants';
import { bibleData } from '../data/bible.ts';

interface BibleModalProps {
  isOpen: boolean;
  onClose: () => void;
  initialState?: { book: string; chapter: number; verse: number } | null;
}

const BibleModal: React.FC<BibleModalProps> = ({ isOpen, onClose, initialState }) => {
  const [selectedBook, setSelectedBook] = useState<string | null>(null);
  const [selectedChapter, setSelectedChapter] = useState<string | null>(null);
  const verseRefs = useRef<Record<string, HTMLParagraphElement | null>>({});

  useEffect(() => {
    if (isOpen && initialState) {
      setSelectedBook(initialState.book);
      setSelectedChapter(initialState.chapter.toString());
      
      setTimeout(() => {
        const key = `${initialState.chapter}-${initialState.verse}`;
        verseRefs.current[key]?.scrollIntoView({ behavior: 'smooth', block: 'center' });
      }, 500);
    }
  }, [isOpen, initialState]);

  if (!isOpen) return null;

  const currentBookData = selectedBook ? bibleData[selectedBook] : null;
  const currentChapterData = (currentBookData && selectedChapter) ? currentBookData[selectedChapter] : null;

  return (
    <div className="fixed inset-0 z-[1000] flex items-center justify-center p-4">
      <div className="absolute inset-0 bg-stone-950/80 backdrop-blur-md" onClick={onClose} />
      <div className="relative w-full max-w-4xl bg-[#fdfcf8] dark:bg-stone-900 rounded-[3rem] shadow-4xl border border-gold/20 flex flex-col max-h-[85vh] overflow-hidden animate-sacred">
        <header className="p-6 border-b border-stone-100 dark:border-stone-800 flex items-center justify-between">
          <div className="flex items-center gap-4">
            <Icons.Book className="w-6 h-6 text-sacred" />
            <h2 className="text-xl font-serif font-bold text-stone-900 dark:text-gold uppercase tracking-widest">Scriptuarium</h2>
          </div>
          <button onClick={onClose} className="p-2 hover:bg-stone-100 dark:hover:bg-stone-800 rounded-full transition-colors">
            <Icons.Cross className="w-5 h-5 rotate-45" />
          </button>
        </header>

        <div className="flex-1 overflow-y-auto p-8 custom-scrollbar">
          {!selectedBook ? (
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-4">
              {Object.keys(bibleData).map(book => (
                <button 
                  key={book} 
                  onClick={() => setSelectedBook(book)}
                  className="p-6 bg-white dark:bg-stone-800 rounded-2xl border border-stone-100 hover:border-gold transition-all text-left font-serif font-bold text-xl"
                >
                  {book}
                </button>
              ))}
            </div>
          ) : !selectedChapter ? (
            <div className="space-y-6">
              <button onClick={() => setSelectedBook(null)} className="text-gold text-xs font-black uppercase tracking-widest flex items-center gap-2">
                <Icons.ArrowDown className="w-3 h-3 rotate-90" /> Voltar aos Livros
              </button>
              <h3 className="text-4xl font-serif font-bold text-center">{selectedBook}</h3>
              <div className="grid grid-cols-5 gap-3">
                {currentBookData && Object.keys(currentBookData).map(ch => (
                  <button 
                    key={ch} 
                    onClick={() => setSelectedChapter(ch)}
                    className="aspect-square bg-white dark:bg-stone-800 rounded-xl flex items-center justify-center font-serif text-2xl font-bold border border-stone-100 hover:bg-gold hover:text-stone-900 transition-all"
                  >
                    {ch}
                  </button>
                ))}
              </div>
            </div>
          ) : (
            <div className="space-y-8 pb-10">
              <button onClick={() => setSelectedChapter(null)} className="text-gold text-xs font-black uppercase tracking-widest flex items-center gap-2">
                <Icons.ArrowDown className="w-3 h-3 rotate-90" /> Voltar aos Capítulos
              </button>
              <h3 className="text-3xl font-serif font-bold border-b border-gold/10 pb-4">{selectedBook} {selectedChapter}</h3>
              <div className="space-y-6 font-serif text-2xl leading-relaxed text-stone-800 dark:text-stone-200">
                {currentChapterData && Object.entries(currentChapterData).map(([vNum, text]) => (
                  <p 
                    key={vNum} 
                    ref={el => verseRefs.current[`${selectedChapter}-${vNum}`] = el}
                    className={`transition-all duration-1000 p-2 rounded ${initialState?.verse.toString() === vNum ? 'bg-gold/20 ring-1 ring-gold/40' : ''}`}
                  >
                    <sup className="text-xs font-sans font-black mr-2 text-gold">{vNum}</sup>
                    {text as string}
                  </p>
                ))}
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default BibleModal;
