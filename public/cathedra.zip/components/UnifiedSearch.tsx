
import React, { useState, useMemo } from 'react';
import { Search, BookOpen, Scroll } from 'lucide-react';
import { bibleData } from '../data/bible';
import { catechismData } from '../data/catechism';

interface UnifiedSearchProps {
  onSelectResult: (type: 'biblia' | 'catecismo', data: any) => void;
}

const UnifiedSearch: React.FC<UnifiedSearchProps> = ({ onSelectResult }) => {
  const [query, setQuery] = useState("");
  
  const results = useMemo(() => {
    if (query.length < 3) return { biblia: [], catecismo: [] };
    const q = query.toLowerCase();
    
    const bibliaRes: any[] = [];
    Object.entries(bibleData).forEach(([book, chapters]) => {
      Object.entries(chapters).forEach(([chapter, verses]) => {
        Object.entries(verses as Record<string, string>).forEach(([vNum, text]) => {
          if (text.toLowerCase().includes(q)) {
            bibliaRes.push({ book, chapter: parseInt(chapter), verse: parseInt(vNum), text });
          }
        });
      });
    });

    const catecismoRes: any[] = [];
    catechismData.forEach((part: any) => {
      part.paragraphs.forEach((para: any) => {
        if (para.text.toLowerCase().includes(q)) {
          catecismoRes.push(para);
        }
      });
    });

    return { biblia: bibliaRes.slice(0, 5), catecismo: catecismoRes.slice(0, 5) };
  }, [query]);

  return (
    <div className="w-full max-w-4xl mx-auto p-4 md:p-6 relative z-[150]">
      <div className="relative group transform hover:scale-[1.01] transition-all duration-700">
        <Search className="absolute left-8 top-1/2 -translate-y-1/2 text-gold" size={28} />
        <input 
          value={query} 
          onChange={e => setQuery(e.target.value)} 
          placeholder="Busque Eucaristia, Verbo, Cristologia..." 
          className="w-full pl-20 pr-8 py-8 md:py-9 bg-stone-900/80 backdrop-blur-2xl text-white shadow-4xl rounded-[3rem] text-xl md:text-2xl font-serif outline-none border border-gold/10 focus:border-gold/40 focus:ring-4 focus:ring-gold/5 transition-all placeholder:text-stone-600" 
        />
      </div>
      
      {query.length >= 3 && (
        <div className="absolute top-full left-0 right-0 mt-6 bg-[#151310] shadow-4xl rounded-[3.5rem] p-8 md:p-12 max-h-[65vh] overflow-y-auto border border-gold/10 z-[160] text-left space-y-10 animate-fade-in no-scrollbar backdrop-blur-3xl">
           {results.biblia.length > 0 && (
             <div className="space-y-6">
                <h4 className="text-[10px] font-black uppercase tracking-[0.4em] text-stone-500 px-4">Resultados na Escritura</h4>
                <div className="space-y-4">
                  {results.biblia.map((r, i) => (
                    <div key={`b-${i}`} onClick={() => { onSelectResult('biblia', r); setQuery(""); }} className="p-8 bg-white/5 border border-white/5 rounded-[2rem] cursor-pointer hover:bg-gold/10 hover:border-gold/30 transition-all group">
                       <div className="text-xs font-bold text-gold mb-3 flex items-center gap-2">
                          <BookOpen size={14} className="text-gold" /> {r.book} {r.chapter}:{r.verse}
                       </div>
                       <p className="text-stone-300 italic font-serif text-lg md:text-xl line-clamp-2 leading-relaxed">"{r.text}"</p>
                    </div>
                  ))}
                </div>
             </div>
           )}
           
           {results.catecismo.length > 0 && (
             <div className="space-y-6">
                <h4 className="text-[10px] font-black uppercase tracking-[0.4em] text-stone-500 px-4">Resultados na Tradição</h4>
                <div className="space-y-4">
                  {results.catecismo.map((r, i) => (
                    <div key={`c-${i}`} onClick={() => { onSelectResult('catecismo', r); setQuery(""); }} className="p-8 bg-white/5 border border-white/5 rounded-[2rem] cursor-pointer hover:bg-sacred/20 hover:border-sacred/40 transition-all group">
                       <div className="text-xs font-bold text-sacred mb-3 flex items-center gap-2">
                          <Scroll size={14} className="text-sacred" /> Catecismo § {r.number} • <span className="text-stone-500 uppercase text-[9px] font-black">{r.context}</span>
                       </div>
                       <p className="text-stone-300 font-serif text-lg md:text-xl line-clamp-2 leading-relaxed">"{r.text}"</p>
                    </div>
                  ))}
                </div>
             </div>
           )}

           {results.biblia.length === 0 && results.catecismo.length === 0 && (
             <div className="py-16 text-center text-stone-500 font-serif italic text-2xl">
               Nenhum mistério encontrado para sua busca.
             </div>
           )}
        </div>
      )}
    </div>
  );
};

export default UnifiedSearch;
