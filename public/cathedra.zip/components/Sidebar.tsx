
import React from 'react';
import { Icons, Logo } from '../constants';
import { AppRoute, User } from '../types';

interface SidebarProps {
  currentPath: AppRoute;
  onNavigate: (p: AppRoute) => void;
  onOpenQuickBible: () => void;
  onOpenQuickDocs: () => void;
  onOpenQuickCIC: () => void;
  onOpenPersonalPrayer: () => void;
  onClose?: () => void;
  user: User | null;
}

const Sidebar: React.FC<SidebarProps> = ({ 
  currentPath, 
  onNavigate, 
  onOpenPersonalPrayer,
  onClose, 
  user 
}) => {
  const sections = [
    {
      label: 'Santuário (Vida de Oração)',
      items: [
        { label: 'Nártex (Início)', path: AppRoute.DASHBOARD, icon: <Icons.Home className="w-5 h-5" /> },
        { label: 'Liturgia Diária', path: AppRoute.DAILY_LITURGY, icon: <Icons.History className="w-5 h-5" /> },
        { label: 'Santo do Dia', path: AppRoute.SAINTS, icon: <Icons.Users className="w-5 h-5" /> },
        { label: 'Santo Rosário', path: AppRoute.ROSARY, icon: <Icons.Star className="w-5 h-5" /> },
        { label: 'Via Crucis', path: AppRoute.VIA_CRUCIS, icon: <Icons.Cross className="w-5 h-5 text-sacred" /> },
        { label: 'Tesouro de Orações', path: AppRoute.PRAYERS, icon: <Icons.Heart className="w-5 h-5" /> },
        { label: 'Nova Oração Pessoal', action: onOpenPersonalPrayer, icon: <Icons.Feather className="w-5 h-5 text-gold" /> },
      ]
    },
    {
      label: 'Scriptorium (Fontes)',
      items: [
        { label: 'Bíblia Sagrada', path: AppRoute.BIBLE, icon: <Icons.Book className="w-5 h-5" /> },
        { label: 'Catecismo (CIC)', path: AppRoute.CATECHISM, icon: <Icons.Scroll className="w-5 h-5" /> },
        { label: 'Magistério', path: AppRoute.MAGISTERIUM, icon: <Icons.Globe className="w-5 h-5" /> },
        { label: 'Breviário Romano', path: AppRoute.BREVIARY, icon: <Icons.History className="w-5 h-5" /> },
        { label: 'Missale Romanum', path: AppRoute.MISSAL, icon: <Icons.Book className="w-5 h-5" /> },
      ]
    },
    {
      label: 'Academia (Intelecto)',
      items: [
        { label: 'Investigação IA', path: AppRoute.STUDY_MODE, icon: <Icons.Search className="w-5 h-5" /> },
        { label: 'Trilhas de Formação', path: AppRoute.TRILHAS, icon: <Icons.Layout className="w-5 h-5" /> },
        { label: 'Opera Omnia (Aquinate)', path: AppRoute.AQUINAS_OPERA, icon: <Icons.Feather className="w-5 h-5" /> },
        { label: 'Certamen (Quiz)', path: AppRoute.CERTAMEN, icon: <Icons.Star className="w-5 h-5" /> },
        { label: 'Poenitentia (Confissão)', path: AppRoute.POENITENTIA, icon: <Icons.Cross className="w-5 h-5" /> },
      ]
    }
  ];

  const handleNav = (item: any) => {
    if (item.action) {
      item.action();
      if (onClose) onClose();
      return;
    }
    
    if (item.path) {
      onNavigate(item.path);
      if (onClose) onClose();
    }
  };

  return (
    <aside className="h-full w-80 bg-white dark:bg-stone-900 border-r border-stone-100 dark:border-white/5 flex flex-col p-6 overflow-hidden">
      <div className="mb-10 px-2 flex items-center gap-3 cursor-pointer group" onClick={() => onNavigate(AppRoute.DASHBOARD)}>
        <Logo className="w-9 h-9" />
        <div>
          <h1 className="text-lg font-black tracking-tight text-stone-900 dark:text-gold leading-none uppercase">CATHEDRA</h1>
          <p className="text-[8px] font-black uppercase text-stone-400 tracking-widest mt-1">Digital Sanctuarium</p>
        </div>
      </div>

      <nav className="flex-1 space-y-8 overflow-y-auto custom-scrollbar pb-10">
        {sections.map((section) => (
          <div key={section.label}>
            <h3 className="text-[9px] font-black uppercase tracking-[0.2em] text-stone-300 dark:text-stone-700 mb-4 px-4">
              {section.label}
            </h3>
            <ul className="space-y-1">
              {section.items.map((item, idx) => (
                <li key={idx}>
                  <button
                    onClick={() => handleNav(item)}
                    className={`w-full flex items-center gap-4 px-4 py-2.5 rounded-xl text-sm font-semibold transition-all
                      ${item.path && currentPath === item.path 
                        ? 'bg-stone-900 text-gold shadow-lg dark:bg-gold dark:text-stone-900' 
                        : 'text-stone-500 hover:bg-stone-50 dark:hover:bg-stone-800 hover:text-stone-900 dark:hover:text-gold'}`}
                  >
                    <span className="opacity-70">{item.icon}</span>
                    <span className="tracking-tight">{item.label}</span>
                    {item.path && currentPath === item.path && <div className="ml-auto w-1 h-1 rounded-full bg-sacred" />}
                  </button>
                </li>
              ))}
            </ul>
          </div>
        ))}
      </nav>

      <div className="pt-6 border-t border-stone-100 dark:border-white/5">
        {user ? (
          <button 
            onClick={() => onNavigate(AppRoute.PROFILE)}
            className="w-full flex items-center gap-3 p-3 bg-stone-50 dark:bg-stone-800 rounded-2xl hover:border-gold border border-transparent transition-all"
          >
            <div className="w-10 h-10 rounded-xl bg-stone-900 dark:bg-gold flex items-center justify-center text-gold dark:text-stone-900 font-black shadow-sm">
              {user.name.charAt(0)}
            </div>
            <div className="flex-1 min-w-0 text-left">
              <p className="text-xs font-bold truncate text-stone-900 dark:text-stone-100">{user.name}</p>
              <p className="text-[8px] uppercase text-gold font-black tracking-widest">Scholar</p>
            </div>
          </button>
        ) : (
          <button 
            onClick={() => onNavigate(AppRoute.LOGIN)}
            className="w-full py-4 bg-stone-900 text-gold dark:bg-gold dark:text-stone-900 rounded-2xl font-black uppercase text-[10px] tracking-widest shadow-xl hover:scale-[1.02] transition-all"
          >
            Acessar Conta
          </button>
        )}
      </div>
    </aside>
  );
};

export default Sidebar;
