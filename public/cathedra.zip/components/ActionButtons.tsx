
import React, { useState, useEffect, memo } from 'react';
import { Icons } from '../constants';
import { SavedItem } from '../types';
import VoicePlayer from './VoicePlayer';

interface ActionButtonsProps {
  itemId: string;
  type: SavedItem['type'];
  title: string;
  content?: string;
  metadata?: any;
  className?: string;
}

const ActionButtons: React.FC<ActionButtonsProps> = ({ 
  itemId, 
  type, 
  title, 
  content, 
  metadata, 
  className = ""
}) => {
  const [isBookmarked, setIsBookmarked] = useState(false);
  const [isCopied, setIsCopied] = useState(false);

  useEffect(() => {
    const bookmarks: SavedItem[] = JSON.parse(localStorage.getItem('cathedra_saved_items') || '[]');
    setIsBookmarked(bookmarks.some(b => b.id === itemId));
  }, [itemId]);

  const toggleBookmark = (e: React.MouseEvent) => {
    e.stopPropagation();
    const bookmarks: SavedItem[] = JSON.parse(localStorage.getItem('cathedra_saved_items') || '[]');
    const isAlready = bookmarks.some(b => b.id === itemId);
    
    let next;
    if (isAlready) {
      next = bookmarks.filter(b => b.id !== itemId);
      setIsBookmarked(false);
    } else {
      const newItem: SavedItem = {
        id: itemId,
        type,
        title,
        content: content || "",
        metadata,
        timestamp: new Date().toISOString()
      };
      next = [...bookmarks, newItem];
      setIsBookmarked(true);
    }
    
    localStorage.setItem('cathedra_saved_items', JSON.stringify(next));
    window.dispatchEvent(new CustomEvent('cathedra-saved-updated'));
  };

  const copyToClipboard = (e: React.MouseEvent) => {
    e.stopPropagation();
    const text = `${title}\n\n${content}`;
    navigator.clipboard.writeText(text);
    setIsCopied(true);
    setTimeout(() => setIsCopied(false), 2000);
  };

  return (
    <div className={`flex items-center gap-2 ${className}`}>
      {content && <VoicePlayer text={content} className="hover:text-gold" />}
      
      <div className="w-px h-4 bg-stone-200 dark:bg-stone-700 mx-1" />

      <button 
        onClick={toggleBookmark}
        className={`p-3 rounded-xl transition-all active:scale-90 flex items-center justify-center gap-2 ${isBookmarked ? 'text-sacred bg-sacred/5' : 'text-stone-400 hover:bg-stone-100 dark:hover:bg-stone-800 hover:text-stone-900 dark:hover:text-white'}`}
        title="Guardar no Florilégio"
      >
        <Icons.Star className={`w-4 h-4 ${isBookmarked ? 'fill-current' : ''}`} />
        <span className="text-[9px] font-black uppercase tracking-widest hidden md:block">Guardar</span>
      </button>

      <button 
        onClick={copyToClipboard}
        className={`p-3 rounded-xl transition-all active:scale-90 flex items-center justify-center gap-2 ${isCopied ? 'text-emerald-600 bg-emerald-50' : 'text-stone-400 hover:bg-stone-100 dark:hover:bg-stone-800 hover:text-stone-900 dark:hover:text-white'}`}
        title="Copiar para Área de Transferência"
      >
        {isCopied ? (
          <span className="text-[9px] font-black uppercase text-emerald-600 tracking-widest">Copiado!</span>
        ) : (
          <>
            <Icons.ExternalLink className="w-4 h-4" />
            <span className="text-[9px] font-black uppercase tracking-widest hidden md:block">Copiar</span>
          </>
        )}
      </button>
    </div>
  );
};

export default memo(ActionButtons);
